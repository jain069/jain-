package com.testx.web.api.selenium.restassured.qe.ui.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class OrderHistory extends AbstractPageObject{

    @FindBy(xpath = "//*[contains(text(),'Hi')]")
    public static WebElement userName;

    @FindBy(xpath = "//span[text()='Order History']")
    public static WebElement history;

    @FindBy(xpath = "(//p[text()='View Details'])[1]")
    public static WebElement viewDetails;

    @FindBy(xpath = "//span[text()='Reorder All Items']")
    public static WebElement reorderButton;

    @FindBy(xpath = "//p[text()='1 items added to Shopping cart successfully']")
    public static WebElement addedNotification;

    @FindBy(xpath = "(//p[text()='Great White® Pizza - Large'])[2]")
    public static WebElement itemName;

    @FindBy(xpath = "//p[text()='Total']")
    public static WebElement totalAmount;

    @FindBy(xpath = "(//*[contains(text(),'Checkout')])[2]")
    public static WebElement checkOut;

    @FindBy(xpath = "//button[@aria-label='Add Gift Button']")
    public static WebElement addButton;

    @FindBy(xpath = "//input[@aria-label='Gift Card Number']")
    public static WebElement giftCardNumber;

    @FindBy(xpath = "//input[@aria-label='PIN']")
    public static WebElement pinNumber;

    @FindBy(xpath = "//button[@aria-label='Label Text']")
    public static WebElement applyCardButton;

    @FindBy(xpath = "//*[text()='Order History']")
    public static WebElement orderHistory;

    @FindBy(xpath = "//button[contains(@aria-label, '21975181')][1]")
    public static WebElement reOrderButton;

    //CheckOutPage
    @FindBy(xpath = "//*[contains(@id, 'chakra-modal--body')]//*[text()='Build Your Own Pizza - Large']")
    public static WebElement productAdded;

    @FindBy(xpath = "//*[text()='Dine In']")
    public static WebElement dineInTab;

    @FindBy(xpath = "//*[text()='Continue your order']")
    public static WebElement continueYourOrder;

    @FindBy(xpath = "//*[contains(@id, 'chakra-modal--body')]//*[text()='Dine In']")
    public static WebElement dineInText;











}
