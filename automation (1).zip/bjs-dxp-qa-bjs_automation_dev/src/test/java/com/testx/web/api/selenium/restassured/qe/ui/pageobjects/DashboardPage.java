package com.testx.web.api.selenium.restassured.qe.ui.pageobjects;

import com.sun.codemodel.JCatchBlock;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.List;

public class DashboardPage extends AbstractPageObject {

    @FindBy(xpath = "//p[contains(text(),'#')]")
    public static WebElement symbol;

    @FindBy(xpath = "//p[text()='Dashboard']")
    public static WebElement dashboard;

    @FindBy(xpath = "//p[text()='Order History']")
    public static WebElement OrderHistory;

    @FindBy(xpath = "///p[text()='Log Out']")
    public static WebElement LogOut;

    @FindBy(xpath = "//span[contains(text(),'Hi')]")
    public static WebElement name;

    @FindBy(xpath = "//span[text()='My Beer Club']")
    public static WebElement beerClubText;


    @FindBy(xpath = "//*[text()='LOG-IN']")
    public static WebElement Login;

    @FindBy(xpath = "//span[text()='Log In']")
    public static WebElement signIn ;

    @FindBy(xpath = "//p[contains(text(),'QMOLABJ')]")
    public static WebElement hashText;

    @FindBy(xpath = "//span[contains(text(),'Dashboard')]")
    public static WebElement dashboardText;

    @FindBy(xpath = "//span[contains(text(),'Account Settings')]")
    public static WebElement accountText;

    @FindBy(xpath = "//span[contains(text(),'Order History')]")
    public static WebElement orderHistoryText;

    @FindBy(xpath = "//span[contains(text(),'Log Out')]")
    public static WebElement logoutText;

    @FindBy(xpath = "//span[contains(text(), 'Account Settings')]")
    public static WebElement accountSettingsButton;

    @FindBy(xpath = "//main/div/div/*[starts-with(@class,'sc')][2]")
    public static WebElement passwordSection;

    @FindBy(xpath = "(//div[contains(@class,'sc-ckMVTt kRXvoz')])[2]/div/div/p")
    public static WebElement passwordSubHeading;

    @FindBy(xpath = "(//div[contains(@class,'sc-ckMVTt kRXvoz')])[2]/div/button")
    public static WebElement editLink;

    @FindBy(xpath = "(//div[contains(@class,'sc-ckMVTt kRXvoz')])[2]/div/div/div/p[2]")
    public static WebElement maskedPassword;

    @FindBy(tagName = "h2")
    public static WebElement passwordHeading;

    @FindBy(tagName = "h2")
    public static WebElement accountSettingHeader;

    @FindBy(css = "div[class='edit-mode'] > form > div > p")
    public static WebElement passwordInfo;

    @FindBy(name = "currentPassword")
    public static WebElement currentPassword;

    @FindBy(name = "newPassword")
    public static WebElement newPassword;

    @FindBy(name = "confirmPassword")
    public static WebElement confirmPassword;

    @FindBy(css = "button[type='submit']")
    public static WebElement updatePasswordButton;

    @FindBy(css = "button[data-testid='cancel']")
    public static WebElement cancelButton;

    @FindBy(css = "div[class='header'] > button")
    public static WebElement closeIcon;

    @FindBy(css = "section[role='dialog']")
    public static WebElement dialogModal;

    @FindBy(css = "section[role='dialog'] > footer > div > button:nth-child(2)")
    public static WebElement unsavedChanges;

    @FindBy(css = "section[role='dialog'] > footer > div > button:nth-child(1)")
    public static WebElement savedChanges;

    @FindBy(css = "main > section:nth-child(1) > p")
    public static WebElement dashboardTitle;

    @FindBy(css = ".gauge")
    public static WebElement progressionBar;

    @FindBy(css = "main > section:nth-child(2) > p")
    public static WebElement subHeading;

    @FindBy(css = ".slick-track")
    public static WebElement rewardsCarousel;

    @FindBy(css = ".slick-track > div")
    public static List<WebElement> rewardsCarouselCards;

    @FindBy(css = ".css-gmuwbf")
    public static WebElement pagination;

    @FindBy(css = ".slick-track img")
    public static WebElement carouselImages;

    @FindBy(css = ".slick-track div[class='css-j7qwjs'] > p:nth-child(1)")
    public static WebElement carouselCardName;

    @FindBy(css = ".slick-track div[class='css-j7qwjs'] > p:nth-child(2)")
    public static WebElement carouselCardDescription;

    @FindBy(xpath = "//div[contains(@class,'slick-track')]//div[contains(@class,'css-j7qwjs')]/following-sibling::p")
    public static WebElement carouselCardExpiryDate;

    @FindBy(xpath = "//div[contains(@class,'slick-track')]//div[contains(@class,'css-j7qwjs')]/following-sibling::p")
    public static WebElement carouselCardMultiply;

    @FindBy(xpath = "//p[contains(text(), 'Dashboard')]")
    public static WebElement dashboardButton;

    @FindBy(css = "button[aria-label='ArrowRight']:nth-child(2)")
    public static WebElement viewAllRewardsButton;

    @FindBy(xpath = "//p[text()='Available Rewards & Offers']")
    public static WebElement viewAllRewardsHeading;

    @FindBy(xpath = "//span[@data-testid='icon']/following-sibling::div[@class='css-0']")
    public static WebElement descriptionRewards;

    @FindBy(css = "div[role='tablist'] > button:nth-child(2)")
    public static WebElement beerClubRewardsButton;

    @FindBy(xpath = "(//div[@class=\"css-v6mflh\"])[1]/div")
    public static List<WebElement> premiereRewardsCards;

    @FindBy(xpath = "(//div[@class=\"css-v6mflh\"])[2]/div")
    public static List<WebElement> beerClubRewardsCards;

    @FindBy(css = "a[href=\"/account/dashboard\"]")
    public static WebElement accountButton;

    @FindBy(xpath = "//*[text()='My Beer Club']")
    public static WebElement myBeerClub;

    @FindBy(xpath = "//*[text()='Available Rewards and Offers']")
    public static WebElement rewardsOffersHeader;

    @FindBy(xpath = "//*[@tabindex='-1']/descendant::p[1]") //*[@class='sc-jKDlA-D erShHl']/descendant::p[1]
    public static List<WebElement> beerExclusiveLabel;
    @FindBy(xpath = "//*[@class='css-gmuwbf']")
    public static WebElement rewardsPagination;

    @FindBy(xpath = "//*[text()='VIEW ALL REWARDS  & OFFERS']")
    public static WebElement viewAllRewardsAndOffers;

    @FindBy(xpath = "//*[text()='Available Rewards & Offers']")
    public static WebElement headerFromViewAll;

    @FindBy(xpath = "//*[@role='tablist']/button[2]/p")
    public static WebElement beerClubTab;

    @FindBy(xpath = "//*[text()='Beer Pickup Location']")
    public static WebElement beerPickUp;

    @FindBy(css = "div[class=' css-ch4t1q']")
    public static WebElement dropDownLoc;

    @FindBy(xpath = "//*[@type='button']/descendant::p[1]")
    public static WebElement saveMyPreferenceButton;

    @FindBy(xpath = "//*[@class='alert-content']/descendant::p[1]")
    public static WebElement locationSaved;

    @FindBy(xpath = "//*[text()='Order History']")
    public static WebElement buttonOrderHistory;

    @FindBy(xpath = "//*[text()='Add Receipt']")
    public static WebElement buttonAddReceipt;

    @FindBy(xpath = "//*[text()='Missed Transaction']")
    public static WebElement textMissedTransaction;

    @FindBy(xpath = "//*[contains(text(), 'Enter the following information from your receipt.')]")
    public static WebElement textCopyArea;

    @FindBy(xpath = "//*[text()='Purchase Information']")
    public static WebElement textPurchaseInfo;

    @FindBy(xpath = "//*[@data-testid='receipt-number-input']")
    public static WebElement textBoxReceiptNumber;

    @FindBy(xpath = "//*[@data-testid='dateOfReceipt-input']")
    public static WebElement textBoxDateOfReceipt;

    @FindBy(xpath = "//*[@data-testid='subtotal-input']")
    public static WebElement textBoxSubTotal;

    @FindBy(xpath = "//*[text()='Submit Receipt']")
    public static WebElement buttonSubmit;

    @FindBy(xpath = "//*[text()='Receipt Submitted']")
    public static WebElement textHeading;

    @FindBy(xpath = "//*[text()='Receipt submitted successfully.']")
    public static WebElement textConfirmationCopy;

    @FindBy(xpath = "//P[contains(text(),'OKAY')]")
    public static WebElement buttonOkay;

    @FindBy(xpath = "//*[contains(@class, 'main-container')]//*[text()='Order History']")
    public static WebElement textOrderHistory;

    @FindBy(xpath = "//*[text()='Please select a location']")
    public static WebElement errorLocation;

    @FindBy(xpath = "//*[text()='Receipt number is required']")
    public static WebElement errorReceiptNumber;

    @FindBy(xpath = "//*[text()='Receipt date is required']")
    public static WebElement errorDateRequired;

    @FindBy(xpath = "//*[text()='Please provide your subtotal']")
    public static WebElement errorSubTotal;

    @FindBy(xpath = "//div/*[starts-with(@class,'sc')][3]//div[@class='content'][1]/div/p[1]")
    public static WebElement card1Number;

    @FindBy(xpath = "//div/*[starts-with(@class,'sc')][3]//div[@class='content'][1]/div/p[2]")
    public static WebElement card1Date;

    @FindBy(xpath = "//div/*[starts-with(@class,'sc')][3]//div[@class='content'][1]/div/div")
    public static WebElement card1Used;

    @FindBy(xpath = "//div/*[starts-with(@class,'sc')][3]//div[@class='content'][2]/div/p[1]")
    public static WebElement card2Number;

    @FindBy(xpath = "//div/*[starts-with(@class,'sc')][3]//div[@class='content'][2]/div/p[2]")
    public static WebElement card2Date;

    @FindBy(xpath = "//div/*[starts-with(@class,'sc')][3]//div[@class='content'][2]/div/div")
    public static WebElement card2Used;

    @FindBy(xpath = "//div/*[starts-with(@class,'sc')][3]//div[@class='content'][1]/button")
    public static WebElement cardEdit1;

    @FindBy(css = "form[data-testid='payment-form'] input[name='number']")
    public static WebElement numberField;

    @FindBy(css = "form[data-testid='payment-form'] input[name='expiryDate']")
    public static WebElement expiryField;

    @FindBy(css = "form[data-testid='payment-form'] input[name='cvv']")
    public static WebElement cvvField;

    @FindBy(css = "form[data-testid='payment-form'] input[name='zip']")
    public static WebElement zipField;

    @FindBy(css = "div[class='header'] > h1")
    public static WebElement headerPayment;

    @FindBy(css = "button[type='submit']")
    public static WebElement saveChangesButton;

    @FindBy(css = "button[type='submit'] + button + button")
    public static WebElement cancelButtonPay;

    @FindBy(xpath = "//p[text()='Your Order']/following-sibling::*")
    public static WebElement buttonCloseIcon;

    @FindBy(xpath = "//h2[text()='Order Details']")
    public static WebElement textOrderDetails;

    @FindBy(xpath = "//*[text()='Reorder All Items']")
    public static WebElement textReorderitems;

    @FindBy(xpath = "//h1[text()='Beer Club']//following::p[2]")
    public static WebElement rejoin;

    @FindBy(xpath = "//*[contains(@aria-label, 'Close Arial Label')]")
    public static WebElement buttonCloseViewDetails;

    @FindBy(xpath = "//*[contains(@id, 'modal')]//*[text()='Cancel Order']")
    public static WebElement textCancelOrder;

    @FindBy(xpath = "//*[text()='Cancel Order']")
    public static WebElement CancelOrderBtn;

    @FindBy(xpath = "//*[text()='YES, CANCEL']")
    public static WebElement buttonPopUpCancel;

    @FindBy(xpath = "//*[text()='NO, KEEP MY ORDER']")
    public static WebElement buttonPopUpKeepMyOrder;

    @FindBy(xpath = "//*[text()='Cancel My Subscription']")
    public static WebElement cancelMySubscription;

    @FindBy(xpath = "//*[text()='Payment History']")
    public static WebElement paymentHistory;

    //*[text()='Reorder']
    private String beforeCTA = "//*[text()='";
    private String afterCTA = "']";
    public void clickCTAInOrderHistory(WebDriver driver, String CTA) {
        try {
            List<WebElement> elements = driver.findElements(By.xpath(beforeCTA+CTA+afterCTA));
            for (WebElement ele : elements) {
                ele.click();
                break;
            }
        }
        catch (Exception ex) {
            ex.getStackTrace();
            ex.getCause();
        }
    }

    public void verifyTextAtMainPage(WebDriver driver, String text) {
        List<WebElement> elements = driver.findElements(By.xpath(beforeCTA+text+afterCTA));
        for (WebElement ele : elements) {
            if (ele.getText().equalsIgnoreCase(text)) {
                Assert.assertTrue(true);
            }
            else
                Assert.fail("Expected and Actual texts doesn't match");
        }
    }

    @FindBy(xpath = "//form[contains(@data-testid,'payment-form')]//span[contains(text(),'required')]")
    public static List<WebElement> errorValidationLabels;

    @FindBy(xpath = "//*[text()='Cancel My Subscription']")
    public static WebElement cancelMySubsButton;

    @FindBy(xpath = "//*[contains(text(), 'How to Cancel My Beer')]")
    public static WebElement cancelMySubsHeader;

    @FindBy(xpath = "//*[contains(text(), 'Cancel your subscription by clicking the button below')]")
    public static WebElement cancelMySubsDesc1;

    @FindBy(xpath = "//*[contains(text(), 'Your free Premier Rewards PLUS membership will still be active')]")
    public static WebElement cancelMySubsDesc;

    @FindBy(xpath = "//*[contains(@aria-label, 'Close Icon')]")
    public static WebElement xButtonCancelWindow;

    @FindBy(xpath = "//*[text()='Reason for cancellation']/following-sibling::div//input")
    public static WebElement reasonsDropdown;

    @FindBy(xpath = "//*[contains(@href, '/account/beerclub')]//p[1]")
    public static WebElement dontCancelButton;

    @FindBy(xpath = "//h1[contains(span, 'My')]")
    public static WebElement myBeerHeader;

    @FindBy(xpath = "//*[contains(text(), 'Subscription ends:')]")
    public static WebElement giftSubsBannerDate;

    @FindBy(xpath = "//*[contains(text(), ' to continue participating in BJ’s Brewhouse Beer Club.')]")
    public static WebElement giftSubsBannerLabel;

    @FindBy(xpath = "//*[contains(text(), 'Add a payment method')]")
    public static WebElement giftSubsBannerLink;

    @FindBy(xpath = "//img[contains(@src, '/release-card')]")
    public static WebElement imgRelease;

    @FindBy(xpath = "//*[contains(text(),'Very robust Belgian-style Witbier. Aroma of citrus')]")
    public static WebElement descriptionRelease;

    @FindBy(xpath = "//*[contains(text(),'Cancelled on')]")
    public static WebElement cancelledOn;

    @FindBy(xpath = "(//*[contains(text(),'Cancelled')])[1]")
    public static WebElement cancelledText;

    @FindBy(xpath = "(//*[contains(text(),'Pending')])[1]")
    public static WebElement pendingText;

    @FindBy(xpath = "//*[contains(text(),'Your Beer Club Subscription will not be')]")
    public static WebElement notExpiredDescription;

    @FindBy(xpath = "//*[contains(text(),'Your beer club subscription will not be')]")
    public static WebElement expiredDescription;

    @FindBy(xpath = "//*[contains(text(),'Failed')]")
    public static WebElement failedPayment;

    @FindBy(xpath = "//*[text()='Job Title']//following-sibling::p")
    public static WebElement jobTitle;

    @FindBy(xpath = "//*[contains(text(),'Update your payment')]")
    public static WebElement updateYourPayment;

    @FindBy(xpath = "//*[contains(text(),'Payment Methods')]")
    public static WebElement payMethod;

    @FindBy(xpath = "//*[text()='Company Name']//following-sibling::p")
    public static WebElement companyName;

    @FindBy(xpath = "//*[text()='Mobile']//following-sibling::p")
    public static WebElement mobileNum;

    @FindBy(xpath = "//p[text()='Edit']")
    public static WebElement accountEditInfo;

    @FindBy(xpath = "//h2[contains(text(),'Personal Information')]")
    public static WebElement accountPersonalInfoLabel;



}