package com.testx.web.api.selenium.restassured.qe.ui.stepdefinitions.bjs_steps;

import com.testx.web.api.selenium.restassured.qe.common.utils.config.Configuration;
import com.testx.web.api.selenium.restassured.qe.common.utils.config.ConfigurationManager;
import com.testx.web.api.selenium.restassured.qe.ui.context.TestContext;
import com.testx.web.api.selenium.restassured.qe.ui.custom_exceptions.InvalidCommonStepSelectionException;
import com.testx.web.api.selenium.restassured.qe.ui.pageobjects.LoginPage;
import com.testx.web.api.selenium.restassured.qe.ui.stepdefinitions.BaseSetup;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.lang.RandomStringUtils;
import org.apache.http.HttpResponse;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.SQLOutput;
import java.time.Duration;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.stream.Stream;
import com.testx.web.api.selenium.restassured.qe.ui.pageobjects.BJsHomePage;
import org.testng.asserts.SoftAssert;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.testng.AssertJUnit.fail;

public class BJsHomepageStepDef extends BaseSetup {

    private static final Logger LOGGER = LoggerFactory.getLogger(BJsHomepageStepDef.class);
    public static Configuration configuration = ConfigurationManager.getConfiguration();
    TestContext testContext;
    private BJsHomePage bJsHomePage;
    private LoginPage loginPage;

    public BJsHomepageStepDef(TestContext context, BJsHomePage bJsHomePage, LoginPage loginPage) {
        super(context);
        this.testContext = context;
        this.bJsHomePage = bJsHomePage;
        this.loginPage = loginPage;
    }

    @Then("^I verify Carousal section element (.*) has following carousal cards on (.*)$")
    public void verifyCarousalCards(String elementName, String pageClassName, DataTable dataTable) {
        List<WebElement> elements = loadWebElements(elementName, pageClassName);
        Map<String, String> maps = dataTable.asMap(String.class, String.class);
        Stream<Map.Entry<String, String>> stream = maps.entrySet().stream();
        int cards = Integer.parseInt(stream.filter(a -> a.getKey().endsWith("ds")).map(a -> a.getValue()).findFirst().get());
        int numOfCards = bJsHomePage.countNumberOfCards(driver, elements);

        if (numOfCards == cards) {
            Assert.assertTrue("Expected is: " + cards + "But Actual is: " + numOfCards, true);
        } else
            Assert.fail("Expected is: " + cards + "But Actual is: " + numOfCards);

    }

    @Then("^I verify Teaser section element (.*) has following Teaser Tabs on (.*)$")
    public void verifyTeaserTabs(String elementName, String pageClassName, DataTable dataTable) {
        List<WebElement> elements = loadWebElements(elementName, pageClassName);
        Map<String, String> maps = dataTable.asMap(String.class, String.class);
        Stream<Map.Entry<String, String>> stream = maps.entrySet().stream();
        int tabs = Integer.parseInt(stream.filter(a -> a.getKey().endsWith("bs")).map(a -> a.getValue()).findFirst().get());
        int numOfTabs = bJsHomePage.countNumberOfCards(driver, elements);

        if (numOfTabs == tabs) {
            Assert.assertTrue("Expected is: " + tabs + "But Actual is: " + numOfTabs, true);
        } else
            Assert.fail("Expected is: " + tabs + "But Actual is: " + numOfTabs);
    }

    @And("I verify that carousal card with card title {string} is zoomed out on page load")
    public void verifyZoomedImageOnCarousalCards(String cardTitle) {
        bJsHomePage.verifyZoomedImage(driver, cardTitle);
    }

    @And("^I verify that field (.*) on the (.*) has maximum length of (.*) characters$")
    public void verifyMaximumLengthOfTitle(String elementName, String pageClassName, Integer maxlength) {
        bJsHomePage.verifyMaximumLength(driver, loadWebElement(elementName, pageClassName), maxlength);
    }

    @Then("^I verify that the image (.+) is present and visible on the (.+)$")
    public void iVerifyThatTheImageIsPresentAndVisible(String elementName, String pageClassName) {
        String sourceValue;
        WebElement img = loadWebElement(elementName, pageClassName);
        driverManagerUtils.findElementAndHighlight(driver, img, "red");
        if (img.getAttribute("src") != null) {
            sourceValue = img.getAttribute("src");
        } else {
            String style = img.getAttribute("style");
            sourceValue = driverManagerUtils.getImageSource(style);
        }
        HttpResponse response = driverManagerUtils.getResponseFromSource(sourceValue);
        if (response.getStatusLine().getStatusCode() != 200)
            fail("Image is not loading, error code: " + response.getStatusLine().getStatusCode());
        org.testng.Assert.assertTrue(img.isDisplayed(), "Image is not displaying correctly");
    }

    @Then("^I verify that the following text from (.+) should be present and NOT empty on the (.+)$")
    public void verifyTextIsPresentAndNotEmpty(String elementName, String pageClassName) {
        WebElement descriptionText = loadWebElement(elementName, pageClassName);
        driverManagerUtils.findElementAndHighlight(driver, descriptionText, "red");
        org.testng.Assert.assertTrue(descriptionText.isDisplayed() && !descriptionText.getText().isEmpty()
                , "Description text is not displayed or is empty!");
    }

    @Then("^I verify that the following optional text from (.+) should be present and NOT empty on the (.+)$")
    public void verifyTextIsPresentAndNotEmptyOptional(String elementName, String pageClassName) {
        try {
            WebElement descriptionText = loadWebElement(elementName, pageClassName);
            driverManagerUtils.findElementAndHighlight(driver, descriptionText, "red");
            org.testng.Assert.assertTrue(descriptionText.isDisplayed() && !descriptionText.getText().isEmpty()
                    , "Description text is not displayed or is empty!");
        } catch (org.openqa.selenium.NoSuchElementException exception) {
            System.out.println("Element not present at this time");
        }
    }

    @Then("^I verify that (.*?) are visible and has the number required for (desktop|mobile) viewport on the (.*)$")
    public void verifyThereShouldBeCollageImages(String section, String viewport, String webPage) {
        List<WebElement> images = loadWebElements(section, webPage);
        switch (viewport) {
            case "desktop":
                assertThat("Collage images are not matching the expected size of 3",
                        images.size(), is(equalTo(3)));
                break;
            case "mobile":
                assertThat("Collage images are not matching the expected size of 2",
                        images.size(), is(equalTo(2)));
                break;
            default:
                throw new InvalidCommonStepSelectionException(viewport);
        }
        for (WebElement ele : images) {
            driverManagerUtils.findElementAndHighlight(driver, ele, "red");
            HttpResponse response = driverManagerUtils.getResponseFromSource(ele.getAttribute("src"));
            org.testng.Assert.assertTrue(response.getStatusLine().getStatusCode() == 200 && ele.isDisplayed());
        }
    }

    @Then("^I verify that (.*) are visible and NOT empty on the (.*)$")
    public void verifyCardNameDescriptionCarousel(String element, String webPage) {
        SoftAssert softAssertions = new SoftAssert();
        int count = 0;
        WebElement next = BJsHomePage.beerCarouselPagination.findElement(By.cssSelector("div:nth-child(3) > button"));
        List<WebElement> listCards = loadWebElements(element, webPage);
        for (WebElement ele : listCards) {
            driverManagerUtils.findElementAndHighlight(driver, ele, "red");
            softAssertions.assertTrue(!ele.getText().isEmpty() && ele.isDisplayed());
            count++;
            if (count % 3 == 0 && count < listCards.size()) {
                count = 0;
                next.click();
                driverManagerUtils.sleep(1000);
            }
        }
        softAssertions.assertAll();
    }

    @Then("^I verify that (.*) the (.*) are visible$")
    public void verifyThatEachCardImageOnTheBeerCarousel(String element, String webPage) {
        SoftAssert softAssertions = new SoftAssert();
        int count = 0;
        WebElement next = BJsHomePage.beerCarouselPagination.findElement(By.cssSelector("div:nth-child(3) > button"));
        List<WebElement> listCards = loadWebElements(element, webPage);
        for (WebElement ele : listCards) {
            driverManagerUtils.findElementAndHighlight(driver, ele, "red");
            String style = ele.getAttribute("style");
            if (style.contains("http")) {
                String sourceValue = driverManagerUtils.getImageSource(style);
                HttpResponse response = driverManagerUtils.getResponseFromSource(sourceValue);
                softAssertions.assertTrue(ele.isDisplayed() && response.getStatusLine().getStatusCode() == 200);
            } else {
                softAssertions.fail("Image: " + (count + 1) + " is not present");
            }
            count++;
            if (count % 3 == 0) {
                next.click();
                driverManagerUtils.sleep(1000);
            }
        }
        softAssertions.assertAll();
    }

    @When("^I move to the end (.*) using the (.*?) on the (.*) in the (desktop|mobile) viewport$")
    public void navigateEndOfCarousel(String elementCards, String element, String webPage, String viewport) {
        List<WebElement> totalCards = loadWebElements(elementCards, webPage);
        WebElement nextPage = loadWebElement(element, webPage);
        int clickTimes;
        switch (viewport) {
            case "desktop":
                clickTimes = (int) Math.ceil(totalCards.size() / 3.0) - 1;
                break;
            case "mobile":
                clickTimes = totalCards.size() - 1;
                break;
            default:
                throw new InvalidCommonStepSelectionException(viewport);
        }
        for (int i = 1; i <= clickTimes; i++) {
            nextPage.click();
            driverManagerUtils.sleep(1000);
        }
    }

    @Given("I switch the viewport to {string}")
    public void switchTheViewport(String viewport) {
        driverManagerUtils.switchViewport(viewport);
    }

    @And("^I verify that the total number in the (.*) is the same as the (.*) on the (.*)$")
    public void verifyThatTheTotalNumberInThePagination(String element, String element2, String webPage) {
        String paginationNumber = loadWebElement(element, webPage).getText();
        List<WebElement> listCards = loadWebElements(element2, webPage);
        int totalPagination = driverManagerUtils.getTotalNumberPagination(paginationNumber);
        assertThat("[Total number are not matching: Pagination: " + totalPagination + " != " + listCards.size() + "]",
                totalPagination, is(equalTo(listCards.size())));
    }

    @And("I enter the text {string} for element {string} on {string}")
    public void enterText(String text, String element, String pageClass) throws InterruptedException {

        try {
            // Thread.sleep(5000);
            String ele1 = "changeLocationButton";
            String page = "OrderTypePage";
            WebElement changeLocCTA = loadWebElement(ele1, page);
            driverManagerUtils.clickElement(driver, changeLocCTA);

            WebElement ele = loadWebElement(element, pageClass);
            driverManagerUtils.clickElement(driver, ele);
            driverManagerUtils.enterText(driver, ele, text);
            Thread.sleep(2000);
        } catch (Exception ex) {
            WebElement ele = loadWebElement(element, pageClass);
            driverManagerUtils.enterText(driver, ele, text);
        } finally {
            WebElement ele = loadWebElement(element, pageClass);
            ele.sendKeys(text);
            ele.sendKeys(Keys.chord(Keys.CONTROL, "a"));
            ele.sendKeys(Keys.BACK_SPACE);
            Thread.sleep(2000);
            ele.sendKeys(text);
        }
        /*try {
          //  if (driverManagerUtils.isElementDisplayed(driver.findElement(By.cssSelector("button[class='chakra-button sc-ksBlkl itQOlm css-166x0fc']")))) {
             //   driver.findElement(By.cssSelector("button[class='chakra-button sc-ksBlkl itQOlm css-166x0fc']")).click();
                driverManagerUtils.enterText(driver, ele, text);
            Thread.sleep(1000);
                driverManagerUtils.enterText(driver, ele, text);
            Thread.sleep(3000);
                Actions action = new Actions(driver);
                action.moveToElement(ele).click().pause(3000).sendKeys(text).build().perform();*/
        // Thread.sleep(5000);
        //  }
      /*  } catch (Exception ex) {
           // Thread.sleep(5000);
            driverManagerUtils.enterText(driver, ele, text);
            //Thread.sleep(5000);
            Actions action = new Actions(driver);
            action.moveToElement(ele).click().pause(3000).sendKeys(text).build().perform();
          //  Thread.sleep(5000);
        }*/
    }


    @And("^I create user$")
    public void createUser() throws InterruptedException {
        Actions action = new Actions(driver);

        // driver.findElement(By.xpath("//*[text()='LOG-IN']/ancestor::span/following-sibling::span[2]//*[contains(text(), 'SIGN UP')]")).click();
        Thread.sleep(4000);
        WebElement ele = driver.findElement(By.xpath("//*[@aria-label='First name']"));
        ele.click();
        ele.sendKeys(Keys.CONTROL + "A");
        Thread.sleep(2000);
        ele.sendKeys(Keys.DELETE);
        Random randomGenerator = new Random();
        ele.sendKeys("User" + RandomStringUtils.randomAlphabetic(6));
        driver.findElement(By.xpath("//*[@aria-label='Last name']")).sendKeys("abcd");
        WebElement email = driver.findElement(By.xpath("//*[@aria-label='Email']"));
        email.sendKeys("DummyUsers" + RandomStringUtils.randomAlphabetic(4) + "@gmail.com");
        WebElement dob = driver.findElement(By.xpath("//*[@aria-label='Date of birth']"));
        dob.sendKeys("02031994");
        WebElement address = driver.findElement(By.xpath("//*[@aria-label='Address']"));
        loginPage.selectAutoSuggestedTextBox(driver, "NEW New Paltz Plaza, New Paltz, NY, USA", address);
        Thread.sleep(2000);
        driver.findElement(By.xpath("//*[@aria-label='Phone']")).sendKeys("1236547897");

        WebElement loc = driver.findElement(By.xpath("//*[contains(@id, '-live-region')]/following-sibling::div//input"));
        loc.sendKeys("Spain - Spain - Test Location");
        action.moveToElement(loc).click().pause(2000)
                .sendKeys(Keys.DOWN).pause(2000).sendKeys(Keys.ENTER).build().perform();
        Thread.sleep(2000);
        driver.findElement(By.xpath("//*[@aria-label='Password']")).sendKeys("Sapient@1234");
        driver.findElement(By.xpath("//*[@aria-label='Confirm Password']")).sendKeys("Sapient@1234");
        Thread.sleep(2000);
        driver.findElement(By.xpath("//*[contains(text(), 'Privacy Policy.')]/ancestor::span/preceding-sibling::span")).click();
        driver.findElement(By.xpath("//*[text()='Create Account']")).click();
        Thread.sleep(10000);
        WebElement element = driver.findElement(By.xpath("//*[contains(@title, 'Restaurant and Brewhouse. Go to homepage')]/span"));
        driverManagerUtils.fluentWaitForElement(driver, element);
        element.click();
        Thread.sleep(10000);
    }

    @And("I enter the value of text {string} for element {string} on {string}")
    public void enterValueOfText(String text, String element, String pageClass) throws InterruptedException {

        try {
            // Thread.sleep(5000);
            String ele1 = "changeLocationButton";
            String page = "OrderTypePage";
            WebElement changeLocCTA = loadWebElement(ele1, page);
            driverManagerUtils.clickElement(driver, changeLocCTA);

            WebElement ele = loadWebElement(element, pageClass);
            driverManagerUtils.clickElement(driver, ele);
            driverManagerUtils.enterText(driver, ele, text);
            Thread.sleep(2000);
        } catch (Exception ex) {
            WebElement ele = loadWebElement(element, pageClass);
            driverManagerUtils.enterText(driver, ele, text);
        } finally {
            WebElement ele = loadWebElement(element, pageClass);
            ele.sendKeys(text);
            ele.sendKeys(Keys.chord(Keys.CONTROL, "a"));
            ele.sendKeys(Keys.BACK_SPACE);
        }
    }
}


