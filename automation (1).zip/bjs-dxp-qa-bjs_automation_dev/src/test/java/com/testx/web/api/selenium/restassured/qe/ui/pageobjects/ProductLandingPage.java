package com.testx.web.api.selenium.restassured.qe.ui.pageobjects;

import com.testx.web.api.selenium.restassured.qe.common.utils.config.ConfigurationManager;
import com.testx.web.api.selenium.restassured.qe.ui.webdriver.DriverManagerUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.List;

public class ProductLandingPage extends AbstractPageObject {

    @FindBy(xpath = "//p[contains(text(),'BACK  TO TOP')]/../button")
    public static WebElement backToTop;

    @FindBy(xpath = "//p[contains(text(),'2000 calories a day is used for general nutrition advice')]")
    public static WebElement endOfCategories;

    @FindBy(xpath = "//button[contains(text(),'Gluten-Sensitive Options')]")
    public static WebElement glutenSensitiveLabel;

    @FindBy(xpath = "//*[text()='BEVERAGES']")
    public static WebElement beveragesLabel;

    @FindBy(xpath = "//*[text()='Soups and Salads']")
    public static WebElement menuSoupsSalads;

    @FindBy(xpath = "//*[text()='SOUPS AND SALADS']")
    public static WebElement soupsSaladsLabel;

    @FindBy(css = ".sc-jOhDuK.hGUjWL > span > p:first-child")
    public static WebElement menuButton;

    @FindBy(css = ".viewall.css-0 > p >a:first-child")
    public static WebElement viewFullMenu;

    @FindBy(xpath = "//*[text()='FILTER']")
    public static WebElement filterButton;

    @FindBy(xpath = "//p[text()='BEVERAGES']")
    public static WebElement beveragesTitle;

    @FindBy(css = ".sc-jGprRt.kAlMWG > span > button > span:first-child")
    public static WebElement favoriteIcon;

    @FindBy(xpath = "//input[@data-testid='search-input']")
    public static WebElement searchBar;

    @FindBy(xpath = "//*[contains(@aria-label,'Submit')]")
    public static WebElement magnifierIcon;

    @FindBy(xpath = "//h1[contains(text(),'Menu')]")
    public static WebElement menuTitle;

    @FindBy(xpath = "//*[@class='chakra-portal']/descendant::section[1]")
    public static WebElement filterModalWindow;

    @FindBy(css = ".title-container > p:first-child")
    public static WebElement filterWindowTitle;

    // Filter Modal Window Open

    @FindBy(xpath = "//*[@class='chakra-modal__body modal-body css-79z5gx']/descendant::p[1]")
    public static WebElement whatsPopularFilterTitle;

    @FindBy(xpath = "//*[@class='chakra-modal__header css-9fgtzh']/descendant::span[1]")
    public static WebElement closeFilterModalButton;

    @FindBy(css = ".css-o33344 >  div > label > span:nth-child(2)")
    public static List<WebElement> allCheckBoxes;

    @FindBy(css = "footer > button:nth-child(1)")
    public static WebElement applyFiltersButton;

    @FindBy(css = "footer > button:nth-child(2)")
    public static WebElement clearAllButton;

    @FindBy(css = "input[value*=NEW]")
    public static WebElement newButton;

    @FindBy(css = "input[value*=Enlightened]")
    public static WebElement enlightenedButton;

    @FindBy(xpath = "//p[text()='NEW']")
    public static WebElement newChip;

    @FindBy(xpath = "//p[text()='Enlightened']")
    public static WebElement enlightenedChip;

    @FindBy(xpath = "//*[@id='__next']//div[1]/span[1]/div/span")
    public static WebElement closeNewChip;

    @FindBy(xpath = "//p[text()='CLEAR ALL']")
    public static WebElement clearAllChipsButton;

    @FindBy(xpath = "//*[@tabindex='0']/descendant::div[5]")
    public static List<WebElement> filterResults;

    @FindBy(xpath = "//p[text()='ENLIGHTENED ENTREES®']")
    public static WebElement enlightenedEnt;

    @FindBy(xpath = "//*[contains(text(),'Appetizer')]")
    public static WebElement appetizersTitle;

    @FindBy(xpath = "//*[text()='Results for']")
    public static WebElement resultsMessage;

    @FindBy(xpath = "//*[text()=\"BJ's Handcrafted Black Cherry Soda\"]")
    public static WebElement sodaResult;

    @FindBy(xpath = "(//p[contains(text(),'Pizza')])[2]")
    public static WebElement secondPizzaItem;

    @FindBy(xpath = "//*[@tabindex='0']//following::img[3]//following::button[1]")
    public static WebElement addToCartThirdItem;

    @FindBy(xpath = "//*[@class='css-8atqhb']/descendant::button[1]")
    public static WebElement xButtonBar;

    @FindBy(xpath = "//*[@class='chakra-link linkStyles css-h4e11i']/descendant::p[1]")
    public static List<WebElement> tri_TipResult;

    @FindBy(xpath = "//p[text()='We could not find any results']")
    public static WebElement noResultResponse;

    @FindBy(xpath = "//p[text()='Sorry but nothing matched your search and filter criteria. Please try again']")
    public static WebElement noResultDescription;

    @FindBy(xpath = "//p[text()='Sorry but nothing matched your search criteria. Please try again with different keywords']")
    public static WebElement noResultDescriptionSearch;

    public int numberOfFields(WebDriver driver, List<WebElement> elementList) {
        int count = 0;
        for (WebElement ele : elementList) {
            count++;
        }
        System.out.println("Total count is: " + count);
        return count;
    }

    @FindBy(xpath = "//*[text()='GLUTEN-SENSITIVE OPTIONS']")
    public static WebElement glutenSensitiveOptionsLabel;

    @FindBy(xpath = "//*[text()='BEVERAGES']")
    public static WebElement mobileMenuBeveragesLabel;

    @FindBy(xpath = "//*[@class='icon-bjs-chevron-down undefined']")
    public static WebElement mobileChevronMenuBt;

    @FindBy(xpath = "//*[text()='Allergen Menu']")
    public static WebElement mobileAllergenPMenuLink;

    @FindBy(xpath = "//*[text()='Nutrition Menu']")
    public static WebElement mobileNutritionPMenuLink;

    @FindBy(xpath = "//*[text()='Catering']")
    public static WebElement mobileCateringMenuLink;

    @FindBy(xpath = "//p[text()='Beverages']")
    public static WebElement MenuBeveragesLabel;

    @FindBy(xpath = "//*[text()='Allergen Menu']")
    public static WebElement AllergenPMenuLink;

    @FindBy(xpath = "//*[text()='Nutrition Menu']")
    public static WebElement NutritionMenuLink;

    @FindBy(xpath = "//*[text()='Catering']")
    public static WebElement CateringMenuLink;

    @FindBy(xpath = "//*[text()='PASTA FAVORITES']")
    public static WebElement pastaFAVORITES;

    @FindBy(xpath = "//*[contains(@class, 'stack-1')]")
    public static WebElement cart;

    @FindBy(xpath = "//header//p")
    public static WebElement textYourOrder;

    @FindBy(xpath = "//footer//button")
    public static WebElement buttonCheckout;

    @FindBy(xpath = "//*[text()='Menu']")
    public static WebElement textMenu;

    @FindBy(xpath = "//*[text()='FILTER']")
    public static WebElement textFilter;

    @FindBy(css = "img[alt=\"BJ's Handcrafted Black Cherry Soda\"]")
    public static WebElement BeveragesImage;

    @FindBy(css = "img[alt=\"House Salad\"]")
    public static WebElement SoapsSaladImage;

    @FindBy(xpath = "//*[contains(@aria-label,'Shopping Cart')]")
    public static WebElement shoppingCartBag;

    @FindBy(xpath = "//*[text()='Order Details']/following-sibling::button/p")
    public static WebElement buttonEditOrder;

    @FindBy(xpath = "//*[text()='Change Location']")
    public static WebElement buttonChangeLocation;

    @FindBy(xpath = "//*[text()='Westwood']/ancestor::div[contains(@class, 'sc-kT')]/following-sibling::div//*[text()='ORDER AHEAD']")
    public static WebElement buttonOrderAhead;

    @FindBy(xpath = "//*[text()='Menu Change']")
    public static WebElement textMenuChange;

    @FindBy(xpath = "//*[contains(text(), 'This location has a different menu, some items in the cart may not be available. Do you want to continue?')]")
    public static WebElement alertDescription;

    @FindBy(xpath = "//*[contains(text(), 'Keep This Location')]")
    public static WebElement buttonKeepLocation;

    @FindBy(xpath = "//*[text()='Change Location']/ancestor::div[contains(@class, 'sc-eT')]/following-sibling::div//button")
    public static WebElement buttonContinueToCheckout;

    @FindBy(xpath = "//*[text()='Continue your order']")
    public static WebElement buttonContinueYourOrder;

    @FindBy(xpath = "//p[text()='Westwood']")
    public static WebElement changedLocation;

    @FindBy(xpath = "//*[text()='Grilled Chicken Alfredo']")
    public static WebElement textGrilledChicken;

    @FindBy(xpath = "//*[text()='Menu Change']/parent::div/following-sibling::button")
    public static WebElement buttonClosePopup;

    @FindBy(xpath = "//p[text()='New Italiano Vegetable Penne']")
    public static WebElement textPenne;

    @FindBy(xpath = "//*[@aria-label='decrement-button']/parent::*/following-sibling::*/span")
    public static WebElement editPencil;

    //*[text()='New Italiano Vegetable Penne']/ancestor::div[contains(@class, 'sc-jO')]/preceding-sibling::div//button
    String beforePath = "//*[@alt=\"";
    String afterPath = "\"]/following-sibling::span[@class='sc-fctJkW iKXbQm']";

    public void isClickMenuItem(WebDriver driver, String menuItem) {
        driver.findElement(By.xpath(beforePath + menuItem + afterPath)).click();
    }

    @FindBy(xpath = "//*[contains(text(), 'Famous Pizzas For Dine-In or Take-out')]")
    public static WebElement pizzaCategory;

    @FindBy(xpath = "//button[contains(text(), 'Pizza')]")
    public static WebElement pizzaCategoryMenu;

    @FindBy(xpath = "//button[contains(text(), 'Burgers')]")
    public static WebElement BurgersCategory;

    @FindBy(xpath = "//*[contains(text(), 'FAMOUS PIZZAS FOR DINE-IN OR TAKE-OUT')]")
    public static WebElement pizzaLabel;

    @FindBy(xpath = "//*[contains(text(), 'FAMOUS PIZZAS FOR DINE-IN OR TAKE-OUT')]//following-sibling::div/descendant::button[contains(@aria-label, 'Pizza - Mini')][1]")
    public static WebElement pizzaItemToCartButton;

    @FindBy(xpath = "(//button[contains(@aria-label, 'Pizza - Mini')])[1]")
    public static WebElement pizzaItemToCartButton1;

    @FindBy(xpath = "//*[contains(text(),'PIZZA')]//following::button[1]")
    public static WebElement pizza1stItem;

    @FindBy(xpath = "//*[contains(text(),'PIZZA')]//following::p[a][1]")
    public static WebElement pizza1stItemName;

    @FindBy(xpath = "(//*[contains(text(), 'FAMOUS PIZZAS FOR DINE-IN OR TAKE-OUT')]//following-sibling::div/descendant::button[3])[1]")
    public static WebElement pizzaShareable;

    @FindBy(xpath = "(//*[contains(text(), 'FAMOUS PIZZAS FOR DINE-IN OR TAKE-OUT')]//following-sibling::div/descendant::button[3])[1]")
    public static WebElement Product1;

    @FindBy(xpath = "//*[text()='Sandwiches & Tacos']")
    public static WebElement sandwichesAndTacosCategory;

    @FindBy(xpath = "//h2[text()='SANDWICHES & TACOS']")
    public static WebElement sandwichesAndTacosLabel;

    @FindBy(xpath = "//*[text()='California Chicken Club Sandwich']")
    public static WebElement sandwichesAndTacos1stItem;

    @FindBy(xpath = "//button[contains(@aria-label,'Add Build Your Own Pizza - Large')]")
    public static WebElement addItem1;

    @FindBy(xpath = "//button[contains(@aria-label,'Add Build Your Own Pizza - Shareable')]")
    public static WebElement addItem2;

    @FindBy(xpath = "//*[contains(text(),'Item added')]")
    public static WebElement itemAddedToCartMsg;

    @FindBy(xpath = "//div[@aria-live='polite']")
    public static WebElement cartButton;

    @FindBy(xpath = "//*[contains(text(), 'APPETIZER')]")
    public static WebElement appetizersLabel;

    @FindBy(xpath = "//*[contains(text(), 'Burgers')]")
    public static WebElement burgersLabel;

    @FindBy(xpath = "//*[contains(text(),'Bistro Burger')][1]")
    public static WebElement bistroBurgersItem;

    @FindBy(xpath = "//p[contains(text(), 'HB - Beach Blvd')]")
    public static WebElement defaultRestraLoc;

    @FindBy(xpath = "//p[text()='Takeout']")
    public static WebElement defaultDeliveryType;

    @FindBy(xpath = "//p[contains(text(), 'Del Amo')]")
    public static WebElement RestraLoc;

    @FindBy(xpath = "//p[text()='ASAP']")
    public static WebElement deliveryTime;

    @FindBy(xpath = "//*[text()='2 items']")
    public static WebElement itemsAddedOnCart;

    @FindBy(xpath = "//*[text()='1 items']")
    public static WebElement itemAddedOnCart;
    @FindBy(xpath = "(//h1[text()='Your Order']/parent::*/following-sibling::*//p)[1]")
    public static WebElement item1;

    @FindBy(xpath = "(//h1[text()='Your Order']/parent::*/following-sibling::*//p)[6]")
    public static WebElement item2;

    @FindBy(xpath = "(//h1[text()='Your Order']/parent::*/following-sibling::*//p)[2]")
    public static WebElement priceItem1;

    @FindBy(xpath = "(//h1[text()='Your Order']/parent::*/following-sibling::*//p)[7]")
    public static WebElement priceItem2;

    @FindBy(xpath = "(//*[contains(text(), 'Test Location')])[2]")
    public static WebElement testLocation;

    @FindBy(xpath = "(//*[contains(text(), 'Test Location')])")
    public static WebElement testLocation1;

    @FindBy(xpath = "//*[text()='Login']")
    public static WebElement buttonLoginAtCart;

    @FindBy(xpath = "(//*[text()='Your Order'])[1]/following-sibling::*/span")
    public static WebElement ButtonCloseAtCart;

    @FindBy(xpath = "//*[text()='Checkout']")
    public static WebElement Checkout;

    @FindBy(xpath = "//h2[contains(text(), 'RESTAURANT & BREWHOUSE - ROOT BEER, TEA & SODAS ')]")
    public static WebElement titleBrewhouse;

    @FindBy(xpath = "(//div[@role='dialog']//button)[4]")
    public static WebElement addMoreItemsCart;

    @FindBy(xpath = "(//div[@role='dialog']//button)[7]")
    public static WebElement addMoreItemsCartAlt;

    @FindBy(xpath = "(//div[@role='dialog']//button)[4]")
    public static WebElement removeItemCart;

    @FindBy(css = "button[aria-label='Add Sliders*']")
    public static WebElement slidersItem;

    @FindBy(xpath = "(//button[starts-with(@class,'sc')])[1]")
    public static WebElement firstItemLeft;

    @FindBy(xpath = "(//button[starts-with(@class,'sc')])[10]")
    public static WebElement burgerMenu;

    @FindBy(xpath = "(//button[starts-with(@class,'sc')])[10]")
    public static WebElement labelBurger;

    @FindBy(xpath = "//*[contains(text(), 'Yes, I am')]")
    public static WebElement ageVerifyYes;

    @FindBy(xpath = "//p[contains(text(), 'JOIN REWARDS')]")
    public static WebElement joinAtCart;

    @FindBy(xpath = "(//button[@aria-label='Addons added'])[1]")
    public static WebElement addonsFromCart;

    @FindBy(xpath = "(//h1[contains(text(), 'Your Order')])/following-sibling::p")
    public static WebElement noOfCartitems;

    @FindBy(xpath = "(//*[text()='Sign Up Free Pizookie'])[1]")
    public static WebElement rewards;

    @FindBy(xpath = "//p[text()='Unapply']")
    public static WebElement unapplyCTA;

    @FindBy(xpath = "//button[contains(@aria-label,'Button Icon')]//span[contains(@role,'img')]")
    public static WebElement applyCTA;

    @FindBy(xpath = "(//*[text()='Continue Ordering'])")
    public static WebElement confirmLocCTA;


    public String fetchFirstItemNameFromCart(DriverManagerUtils driverManagerUtils, WebDriver driver) {
        driverManagerUtils.fluentWaitForElement(driver, item1);
        return item1.getText();
    }

    public String fetchSecondItemNameFromCart(DriverManagerUtils driverManagerUtils, WebDriver driver) {
        driverManagerUtils.fluentWaitForElement(driver, item2);
        return item2.getText();
    }

    public String fetchFirstItemPriceFromCart(DriverManagerUtils driverManagerUtils, WebDriver driver) {
        driverManagerUtils.fluentWaitForElement(driver, priceItem1);
        return priceItem1.getText();
    }

    public String fetchSecondItemPriceFromCart(DriverManagerUtils driverManagerUtils, WebDriver driver) {
        driverManagerUtils.fluentWaitForElement(driver, priceItem2);
        return priceItem2.getText();
    }
}