package com.testx.web.api.selenium.restassured.qe.ui.stepdefinitions.bjs_steps;

import com.testx.web.api.selenium.restassured.qe.common.utils.config.Configuration;
import com.testx.web.api.selenium.restassured.qe.common.utils.config.ConfigurationManager;
import com.testx.web.api.selenium.restassured.qe.ui.context.TestContext;
import com.testx.web.api.selenium.restassured.qe.ui.pageobjects.BJsHomePage;
import com.testx.web.api.selenium.restassured.qe.ui.pageobjects.LoginPage;
import com.testx.web.api.selenium.restassured.qe.ui.stepdefinitions.BaseSetup;
import com.testx.web.api.selenium.restassured.qe.ui.stepdefinitions.prebuilt_steps.PrebuiltDataAssertionSteps;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Duration;
import java.util.List;

/*import com.testx.web.api.selenium.restassured.qe.ui.config.Configuration;
import com.testx.web.api.selenium.restassured.qe.ui.config.ConfigurationManager;*/
import com.testx.web.api.selenium.restassured.qe.ui.context.TestContext;
import com.testx.web.api.selenium.restassured.qe.ui.stepdefinitions.BaseSetup;
import com.testx.web.api.selenium.restassured.qe.ui.pageobjects.LoginPage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LoginPageStepDef extends BaseSetup {

    private static final Logger LOGGER = LoggerFactory.getLogger(LoginPageStepDef.class);
    public static Configuration configuration = ConfigurationManager.getConfiguration();
    TestContext testContext;
    private LoginPage loginPage;
    public LoginPageStepDef(TestContext context, LoginPage loginPage) {
        super(context);
        this.testContext = context;
        this.loginPage = loginPage;
    }

    @Then("I enter text {string} for element {string} on {string}")
    public void enterAndSelectTextSuggestion(String text, String elementName, String pageClassName) {
        loginPage.selectAutoSuggestedTextBox(driver, text , loadWebElement(elementName, pageClassName));
    }

    @Then("I select {string} from dropdown for element {string} on {string}")
    public void selectTextFromDropdown(String text, String elementName, String pageClassName) throws InterruptedException {
        loginPage.selectFromBootstrapDropdown(driver, text, loadWebElement(elementName, pageClassName));
        Thread.sleep(3000);
    }

    @Then("^I verify image with element (.*) on (.*) is present$")
    public void verifyHeroImage(String elementName, String pageClassName) {
        loginPage.verifyHeroBanner(driver, loadWebElement(elementName, pageClassName));
    }

    @Then("I click Outside email field")
    public void iClickOutsideTheFilterModalWindow() {
        Actions action = new Actions(driver);
        action.moveByOffset(0,0).click().build().perform();
    }
}
