package com.testx.web.api.selenium.restassured.qe.ui.stepdefinitions.bjs_steps;

import com.testx.web.api.selenium.restassured.qe.common.utils.config.Configuration;
import com.testx.web.api.selenium.restassured.qe.common.utils.config.ConfigurationManager;
import com.testx.web.api.selenium.restassured.qe.ui.context.TestContext;
import com.testx.web.api.selenium.restassured.qe.ui.pageobjects.DashboardPage;
import com.testx.web.api.selenium.restassured.qe.ui.stepdefinitions.BaseSetup;
import io.cucumber.java.en.When;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DashboardPageStepDef extends BaseSetup {

    private static final Logger LOGGER = LoggerFactory.getLogger(DashboardPageStepDef.class);
        public static Configuration configuration = ConfigurationManager.getConfiguration();
        TestContext testContext;

    private DashboardPage DashboardPage;
    public DashboardPageStepDef(TestContext context, DashboardPage  DashboardPage) {
        super(context);
        this.testContext = context;
        this.DashboardPage = DashboardPage;
        }



}
