package com.testx.web.api.selenium.restassured.qe.ui.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class PdpToCheckout extends AbstractPageObject{

    @FindBy(xpath = "(//span[@class='chakra-text css-ykew9n'])[3]")
    public static WebElement selectionButton;

    @FindBy(xpath = "//span[@class='stack-1']")
    public static WebElement cartIcon;

    @FindBy(xpath = "//p[@class='chakra-text item css-12xga1t']")
    public static WebElement order;

    @FindBy(xpath = "//p[text()='Loaded Classic Burger | Menu ']")
    public static WebElement itemName;

    @FindBy(xpath = "//p[text()='Subtotal']")
    public static WebElement subTotal;

    @FindBy(xpath = "(//p[text()='Bistro Burger (1)'])[1]")
    public static WebElement Name;

    @FindBy(xpath = "//input[@aria-label='first Name']")
    public static WebElement firstName;

    @FindBy(xpath = "//input[@aria-label='last Name']")
    public static WebElement lastName;

    @FindBy(xpath = "//input[@aria-label='Email']")
    public static WebElement emailID;

    @FindBy(xpath = "//input[@aria-label='*Phone']")
    public static WebElement phoneNumber;

    @FindBy(xpath = "//input[@aria-label='*Card number']")
    public static WebElement cardNumber;

    @FindBy(xpath = "//input[@aria-label='*CVV']")
    public static WebElement cvv;

    @FindBy(xpath = "//input[@aria-label='*Expiration']")
    public static WebElement expiryDate;

    @FindBy(xpath = "//input[@aria-label='*ZIP code']")
    public static WebElement zipCode;

    @FindBy(xpath = "//button[@aria-label='No']")
    public static WebElement utensils;

    @FindBy(xpath = "//span[@class='chakra-text css-1ejxcab']")
    public static WebElement placeOrder;

   @FindBy(xpath = "//p[text()='LOG IN']")
    public static WebElement logIn;

   @FindBy(xpath = "//h1[@class='chakra-heading css-1fvsdtz']")
    public static WebElement classicBurger;

   @FindBy(xpath = "//p[@class='chakra-text css-1021ll9']")
    public static WebElement price;

   @FindBy(xpath = "//p[contains(text(),'BJ’s signature burger sauce ')]")
    public static WebElement itemDescription;


















}

