package com.testx.web.api.selenium.restassured.qe.ui.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class HomePage extends AbstractPageObject {

    @FindBy(xpath = "//span[contains(text(),'Products')]")
    public static WebElement products;

    @FindBy(id = "shopping_cart_container")
    public static WebElement shoppingCartContainer;

    @FindBy(xpath = "//span[contains(text(),'Takeout')]")
    public static WebElement defaultLocation;

    @FindBy(css = "span[class='title']")
    public static WebElement productsMain;

    @FindBy(xpath = "//a[text()='Forgot email or password?']")
    public static WebElement forgotEmail;

    @FindBy(xpath = "//p[text()='Find my Account']")
    public static WebElement findAccount;

    @FindBy(xpath = "//input[@aria-label='Search Account by Phone, Email, Premier Rewards ID']")
    public static WebElement searchEmail;

    @FindBy(xpath = "//p[text()='Search for your account via phone number, Premier Rewards ID, or email.']")
    public static WebElement searchAccount;

    @FindBy(xpath = "//button[@aria-label='Submit account search']")
    public static WebElement submitText;

    @FindBy(xpath = "//p[text()='Is this you?']")
    public static WebElement you;

    @FindBy(xpath = "//p[text()='Name']")
    public static WebElement nameAC;

    @FindBy(xpath = "//p[text()='Email']")
    public static WebElement email;

    @FindBy(xpath = "//p[text()='Mobile']")
    public static WebElement number;

    @FindBy(xpath = "//p[text()='LOG IN']")
    public static WebElement logIn;

    @FindBy(xpath = "//p[text()='SEND RESET PASSWORD LINK']")
    public static WebElement resetLink;

    @FindBy(xpath = "//p[text()='Don’t have an account?']")
    public static WebElement haveAccount;

    @FindBy(xpath = "//a[text()='SIGN UP']")
    public static WebElement signUp;

    @FindBy(xpath = "//p[text()='NO ACCOUNTS FOUND']")
    public static WebElement acFound;

    @FindBy(xpath = "//p[text()='Sorry, but there are no accounts using']")
    public static WebElement bodyTxt;

    @FindBy(xpath = "//p[text()='Ka** Moj***']")
    public static WebElement nameMask;

    @FindBy(xpath = "//p[text()='kat********@g****.com']")
    public static WebElement mailMask;

    @FindBy(xpath = "//p[text()='219*****17']")
    public static WebElement numMask;

    @FindBy(xpath = " //button[@aria-label='close']")
    public static WebElement close;

    @FindBy(xpath = "//span[@class='sc-kDDrLX kqDxGB icon-bjs-logo ']")
    public static WebElement logoHome;

    @FindBy(xpath = "//div[text()='ASAP']")
    public static WebElement ASAPf;

    @FindBy(xpath = "//span[contains(text(), 'Hi')]")
    public static WebElement welcomeText;

    @FindBy(xpath = " //span[text()='Order History']")
    public static WebElement orderHis;

    @FindBy(xpath = "//p[text()='Reorder']")
    public static WebElement reOrder;

    @FindBy(xpath = "//p[text()='Add More Items']")
    public static WebElement addMore;

    @FindBy(xpath = "(//button[contains(@aria-label,'Black Cherry Soda')])[1]")
    public static WebElement addSodaItem;

    @FindBy(xpath = "(//a[contains(@title,'Go to homepage')]//span)[1]")
    public static WebElement logoM;

    @FindBy(xpath = "//p[contains(text(),'Black Cherry Soda')] ")
    public static WebElement itemName;

    @FindBy(xpath = "//p[contains(text(),'Black Cherry Soda')]/../../..//div[3]//p ")
    public static WebElement priceItem;

    @FindBy(xpath = "//p[text()='Subtotal'] ")
    public static WebElement subTotal;

    @FindBy(xpath = "//button[@aria-label='No'] ")
    public static WebElement noUtensils;

    @FindBy(xpath = "//div[text()='Today'] ")
    public static WebElement toDay;

    @FindBy(xpath = "//button[@aria-label='Add Gift Button'] ")
    public static WebElement giftBtn;

    @FindBy(xpath = "//input[@aria-label='Gift Card Number'] ")
    public static WebElement giftCardNum;

    @FindBy(xpath = "//input[@aria-label='PIN'] ")
    public static WebElement pin;

    @FindBy(xpath = "//p[text()='Apply Card'] ")
    public static WebElement applyCard;

    @FindBy(xpath = "//a[@href=\"/account/dashboard\"]/span")
    public static WebElement menuHi;

    @FindBy(xpath = "//p[contains(text(), 'Add More Items')]")
    public static WebElement addMoreItems;

    @FindBy(xpath = "//p[text()='Place Order']")
    public static WebElement placeOrder;

    @FindBy(xpath = "//*[text()='Checkout']")
    public static WebElement checkoutBtn;

    @FindBy(xpath = "(//*[text()='Reorder'])[1]")
    public static WebElement reorderForCancelPdt;

    @FindBy(xpath = "//span[text()='Account Settings']")
    public static WebElement accountSettings;

    @FindBy(xpath = "//*[text()='Edit']")
    public static WebElement edit;

    @FindBy(xpath = " //input[@aria-label='First name']")
    public static WebElement firstName;

    @FindBy(xpath = "//input[@aria-label='Last name']")
    public static WebElement lastName;

    @FindBy(xpath = "//input[@aria-label='Job Title']")
    public static WebElement jobTitle;

    @FindBy(xpath = "//label[text()='Company’s Industry']")
    public static WebElement companyIndustry;

    @FindBy(xpath = "//*[contains(text(),'Apartment')]")
    public static WebElement suite;

    @FindBy(xpath = "//span[text()='SAVE CHANGES']")
    public static WebElement saveChanges;

    @FindBy(xpath = "//input[@aria-label='Phone']")
    public static WebElement phoneN;

    @FindBy(xpath = "//*[@data-testid='companyName']")
    public static WebElement companyName;

    @FindBy(xpath = "//input[@aria-label='address']")
    public static WebElement addressChange;

    @FindBy(xpath = "//*[text()='CATERING']")
    public static WebElement cateringLink;

    @FindBy(xpath = "//a[contains(text(),'Meal Deals')]")
    public static WebElement mealDealsLink;

    @FindBy(xpath = "(//*[contains(text(),'BEER CLUB')])[1]")
    public static WebElement beerClubLink;

    @FindBy(xpath = "//*[contains(text(),'DEALS & MORE')]")
    public static WebElement dealsAndMoreLink;

    @FindBy(xpath = "(//*[contains(text(),'GIFT CARDS')])[1]")
    public static WebElement giftCardLink;


}