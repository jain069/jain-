package com.testx.web.api.selenium.restassured.qe.ui.stepdefinitions.bjs_steps;

import com.testx.web.api.selenium.restassured.qe.common.utils.config.Configuration;
import com.testx.web.api.selenium.restassured.qe.common.utils.config.ConfigurationManager;
import com.testx.web.api.selenium.restassured.qe.ui.context.Context;
import com.testx.web.api.selenium.restassured.qe.ui.context.TestContext;
import com.testx.web.api.selenium.restassured.qe.ui.pageobjects.LocationPage;
import com.testx.web.api.selenium.restassured.qe.ui.stepdefinitions.BaseSetup;
import io.cucumber.java.en.When;
import org.junit.Assert;
import org.openqa.selenium.WebElement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.TimeZone;

import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.MatcherAssert.assertThat;

public class LocationPageStepDef extends BaseSetup {

    private static final Logger LOGGER = LoggerFactory.getLogger(LocationPageStepDef.class);
    public static Configuration configuration = ConfigurationManager.getConfiguration();
    TestContext testContext;
    private LocationPage FindLocationPage;

    public LocationPageStepDef(TestContext context, LocationPage FindLocationPage) {
        super(context);
        this.testContext = context;
        this.FindLocationPage = FindLocationPage;
    }

    @When("I verify for {string} on the {string}")
    public void iVerifyRestaurantStatus(String elementName, String pageClassName) {
        WebElement element = loadWebElement(elementName, pageClassName);
        String resStatus = driverManagerUtils.getElementText(driver, element);
        if (resStatus.equalsIgnoreCase("close")) {
            testContext.scenarioContext.setContext(Context.Time_ASAP, "11");
        } else {
            LocalDateTime now = LocalDateTime.now(ZoneId.of("Canada/Pacific")).plusMinutes(30);
            testContext.scenarioContext.setContext(Context.Time_ASAP, now);
        }
    }

    @When("I verify Order details {string} on the {string}")
    public void iVerifyOrderTime(String elementName, String pageClassName) {
        String expectedText = (String) testContext.scenarioContext.getContext(Context.Time_ASAP);
        String actualText = driverManagerUtils.getElementText(driver, loadWebElement(elementName, pageClassName));
        assertThat("Element text not matching", actualText, containsString(expectedText));
    }
}
