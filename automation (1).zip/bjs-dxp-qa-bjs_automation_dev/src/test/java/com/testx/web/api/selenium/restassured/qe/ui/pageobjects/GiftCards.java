package com.testx.web.api.selenium.restassured.qe.ui.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class GiftCards extends AbstractPageObject{

    @FindBy(xpath = "//a[text()='LOG-IN']")
    public static WebElement loginButton;

    @FindBy(xpath = "//span[@class='stack-1']")
    public static WebElement cartIcon;

    @FindBy(xpath = "//button[@class='chakra-button sc-iqcoie daITTQ css-jb5tx4']")
    public static WebElement checkoutButton;

    @FindBy(xpath = "//*[@aria-label='Add Gift Button']")
    public static WebElement giftCard;

    @FindBy(xpath = "(//button[contains(@aria-label,'Add Gift')])")
    public static WebElement plusButton;

    @FindBy(xpath = "//input[@aria-label='Gift Card Number']")
    public static WebElement giftCardNumber;

    @FindBy(xpath = "//input[@aria-label='PIN']")
    public static WebElement pinNumber;

    @FindBy(xpath = "//p[text()='Apply Card']")
    public static WebElement applyCardButton;

   @FindBy(xpath = "(//p[text()='Order Summary'])[2]")
    public static WebElement orderSummary;






}
