package com.testx.web.api.selenium.restassured.qe.ui.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LocationDetailsPage extends AbstractPageObject {

    @FindBy(xpath = "(//*[text()='ORDER ONLINE'])[1]")
    public static WebElement orderOnline;

    @FindBy(xpath = "(//*[text()='JOIN WAITLIST'])[1]")
    public static WebElement joinWaitList;

    @FindBy(xpath = "(//*[text()='RESERVATIONS'])[1]")
    public static WebElement reservationsCTA;

}
