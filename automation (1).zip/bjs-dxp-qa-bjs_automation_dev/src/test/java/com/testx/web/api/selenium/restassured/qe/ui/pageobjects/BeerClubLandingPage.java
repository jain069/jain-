package com.testx.web.api.selenium.restassured.qe.ui.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.List;

public class BeerClubLandingPage extends AbstractPageObject{

    @FindBy(xpath = "//div/*[starts-with(@class,'title')]")
    public static WebElement howItWorksTitle;
    @FindBy(css = "div[class='StorytellingCardText bclandingpage css-0']")
    public static WebElement howItWorksDescription;
    @FindBy(css = "a[aria-label='Beer Club FAQ Aria Title']")
    public static WebElement howItWorksCTA1;
    @FindBy(css = "a[aria-label='Contact Us  Aria Title']")
    public static WebElement howItWorksCTA2;
    @FindBy(css = "img[alt='Alt Text Image ']")
    public static WebElement howItWorksImage;
    @FindBy(xpath = "//p[contains(text(),'Beer Club Terms')]")
    public static WebElement termsTitle;
    @FindBy(xpath = "(//div[contains(@class,'aem-GridColumn aem-GridColumn--default--12')])[13] //div[starts-with(@class,'description')]")
    public static WebElement termsDescription;
    @FindBy(css = "div[variant='primary']")
    public static WebElement receiveGift;
    @FindBy(xpath = "(//div[contains(@class,'aem-GridColumn aem-GridColumn--default--12')])[12]/div/div")
    public static WebElement howItWorksComponent;
    @FindBy(xpath = "//div/*[starts-with(@class,'current-release-body')]")
    public static WebElement currentReleaseSection;
    @FindBy(xpath = "//h3[text()='Previous Releases']")
    public static WebElement previousReleasesTitle;
    @FindBy(css = "div[data-testid='carousel']")
    public static WebElement carouselSection;
    @FindBy(css = ".slick-track > div")
    public static List<WebElement> releasesCarouselCards;


    //Redeem Gift CTA
    @FindBy(xpath = "(//a[@linktextas='span'])[6]")
    public static WebElement Bjs_Beer_Club;

    @FindBy(xpath = "//p[contains(text(),'REDEEM GIFT')]")
    public static WebElement RedeemGift;

    @FindBy(xpath = "//div[contains(text(),'You can enjoy all the benefits of a Beer Club member by using your code to redeem your gift subscription.')]")
    public static WebElement GiftSubscription;

    //CurrentRelease
    @FindBy(xpath = "//h2[contains(text(),'Current Release')]")
    public static WebElement CurrentRelease;

    @FindBy(xpath = "//span[contains(text(),'VIEW BEER RELEASE DETAILS')]")
    public static WebElement Details;

    @FindBy(xpath = "//p[contains(text(),'Subscriptions')]")
    public static WebElement Subscription;

    @FindBy(xpath = "//p[contains(text(),'Purchase Gift')]")
    public static WebElement Purchase_Gift;

    //BeerClub-PaymentHistory

    @FindBy(xpath = "//span[contains(text(),'Hi')]")
    public static WebElement Hi;

    @FindBy(xpath = "//span[contains(text(),'My Beer Club')]")
    public static WebElement MyBeerClub;

    @FindBy(xpath = "//h2[contains(text(),'Payment History')]")
    public static WebElement PaymentHistory;

    @FindBy(xpath = "")
    public static WebElement Expenses;

    @FindBy(xpath = "//span[contains(text(),'Cancel My Subscription')]")
    public static WebElement CancelMySubscription;

    @FindBy(xpath = "//p[contains(text(),'Purchase Membership')]")
    public static WebElement PurchaseMembership;

    @FindBy(xpath = "")
    public static WebElement Rejoin;








}