package com.testx.web.api.selenium.restassured.qe.ui.stepdefinitions.bjs_steps;

import com.testx.web.api.selenium.restassured.qe.ui.context.TestContext;
import com.testx.web.api.selenium.restassured.qe.ui.pageobjects.CheckoutPage;
import com.testx.web.api.selenium.restassured.qe.ui.pageobjects.DashboardPage;
import com.testx.web.api.selenium.restassured.qe.ui.stepdefinitions.BaseSetup;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.http.HttpResponse;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.asserts.SoftAssert;
import java.util.List;
import java.util.Map;

public class DashboardStepDef extends BaseSetup {
    TestContext testContext;
    private DashboardPage dashboardPage;
    public DashboardStepDef(TestContext context, DashboardPage dashboardPage) {
        super(context);
        this.testContext = context;
        this.dashboardPage = dashboardPage;
    }

    @And("^I verify the cards of the (.*) on the (.*)$")
    public void iVerifyTheCardsOfTheRewardsCarouselOnTheDashboardPage(String element, String webPage) {
        SoftAssert softAssertions = new SoftAssert();
        int count = 0;
        WebElement next = driver.findElement(By.cssSelector("div[class='css-k008qs'] > button[aria-label='ArrowRight']"));
        List<WebElement> listCards = loadWebElements(element, webPage);
        for (WebElement ele : listCards) {
            WebElement img = ele.findElement(By.cssSelector("img"));
            HttpResponse response = driverManagerUtils.getResponseFromSource(img.getAttribute("src"));
            driverManagerUtils.findElementAndHighlight(driver, img, "blue");
            softAssertions.assertTrue(response.getStatusLine().getStatusCode() == 200 && img.isDisplayed());
            try {
                WebElement bc = ele.findElement(By.cssSelector("img+p"));
                driverManagerUtils.findElementAndHighlight(driver, bc, "blue");
                softAssertions.assertTrue(!bc.getText().isEmpty() && bc.isDisplayed());
            }catch (org.openqa.selenium.NoSuchElementException ne){
                System.out.println("This card is not a Beer Club Rewards");
            }
            try{
                WebElement mp = ele.findElement(By.cssSelector("div[class='sc-hZFzCs kEimLV css-0'] > p"));
                driverManagerUtils.findElementAndHighlight(driver, mp, "blue");
                softAssertions.assertTrue(!mp.getText().isEmpty() && mp.isDisplayed());
            }catch (org.openqa.selenium.NoSuchElementException ne){
                System.out.println("Just one Card");
            }
            WebElement title = ele.findElement(By.cssSelector("div[class='css-j7qwjs'] > p:nth-child(1)"));
            driverManagerUtils.findElementAndHighlight(driver, title, "blue");
            softAssertions.assertTrue(!title.getText().isEmpty() && title.isDisplayed());
            WebElement copy = ele.findElement(By.cssSelector("div[class='css-j7qwjs'] > p:nth-child(2)"));
            driverManagerUtils.findElementAndHighlight(driver, copy, "blue");
            softAssertions.assertTrue(!copy.getText().isEmpty() && copy.isDisplayed());
            WebElement expiry = ele.findElement(By.cssSelector("p[class='chakra-text css-10fap9d']"));
            driverManagerUtils.findElementAndHighlight(driver, expiry, "blue");
            softAssertions.assertTrue(!expiry.getText().isEmpty() && expiry.isDisplayed());
            count++;
            if (count % 4 == 0 && count < listCards.size()) {
                count = 0;
                next.click();
                driverManagerUtils.sleep(1000);
            }
        }
        softAssertions.assertAll();
    }

    @And("^I verify the cards of the (.*) of the (.*) in the Rewards Page$")
    public void verifyTheCardsOfTheRewardsPage(String element, String webPage) {
        SoftAssert softAssertions = new SoftAssert();
        List<WebElement> listCards = loadWebElements(element, webPage);
        for (WebElement ele : listCards) {
            WebElement img = ele.findElement(By.cssSelector("img"));
            HttpResponse response = driverManagerUtils.getResponseFromSource(img.getAttribute("src"));
            driverManagerUtils.findElementAndHighlight(driver, img, "blue");
            softAssertions.assertTrue(response.getStatusLine().getStatusCode() == 200 && img.isDisplayed());
            try {
                WebElement bc = ele.findElement(By.cssSelector("img+p"));
                driverManagerUtils.findElementAndHighlight(driver, bc, "blue");
                softAssertions.assertTrue(!bc.getText().isEmpty() && bc.isDisplayed());
            }catch (org.openqa.selenium.NoSuchElementException ne){
                System.out.println("This card is not a Beer Club Rewards");
            }
            try{
                WebElement mp = ele.findElement(By.cssSelector("div[class='sc-hZFzCs kEimLV css-0'] > p"));
                driverManagerUtils.findElementAndHighlight(driver, mp, "blue");
                softAssertions.assertTrue(!mp.getText().isEmpty() && mp.isDisplayed());
            }catch (org.openqa.selenium.NoSuchElementException ne){
                System.out.println("Just one Card");
            }
            WebElement title = ele.findElement(By.cssSelector("div[class='css-j7qwjs'] > p:nth-child(1)"));
            driverManagerUtils.findElementAndHighlight(driver, title, "blue");
            softAssertions.assertTrue(!title.getText().isEmpty() && title.isDisplayed());
            WebElement copy = ele.findElement(By.cssSelector("div[class='css-j7qwjs'] > p:nth-child(2)"));
            driverManagerUtils.findElementAndHighlight(driver, copy, "blue");
            softAssertions.assertTrue(!copy.getText().isEmpty() && copy.isDisplayed());
            WebElement expiry = ele.findElement(By.cssSelector("p[class='chakra-text css-10fap9d']"));
            driverManagerUtils.findElementAndHighlight(driver, expiry, "blue");
            softAssertions.assertTrue(!expiry.getText().isEmpty() && expiry.isDisplayed());
        }
        softAssertions.assertAll();
    }

    @Then("^I verify rewards cards section has the following text in (.*)$")
    public void verifyResultsListSearchCheckOut(String pageClassName, DataTable dataTable) throws InterruptedException {
        List<Map<String, String>> rows = dataTable.asMaps(String.class, String.class);
        WebElement nextPage = DashboardPage.rewardsPagination.findElement(By.xpath("descendant::p[1]"));//descendant::span[2]
        List<WebElement> elements = loadWebElements(rows.get(0).get("Field"), pageClassName);
        int count = 0;
        for (WebElement ele : elements) {
            driverManagerUtils.findElementAndHighlight(driver, ele, "red");
            String resultName = rows.get(0).get("Text");
            String resultText = ele.getText();
            count ++;
            System.out.println(resultText);
            if (count % 4 == 0 && count < elements.size() && resultText.equals(resultName)) {
                nextPage.click();
                Assert.assertTrue("Expected Partially Text is : " + resultName + " And Actual Text is: "
                        + resultText, true);
            }
        }
    }

    @Then("I select an option from DropDown on the My beer Club Screen")
    public void iSelectOnTheDropdown() throws InterruptedException {
        Actions action = new Actions(driver);
        WebElement dp2 = driver.findElement(By.cssSelector("div[class=' css-ch4t1q']"));
        driverManagerUtils.findElementAndHighlight(driver,dp2,"green");
        dp2.click();
        //Thread.sleep(2000);
        List<WebElement> ele = driver.findElements(By.cssSelector("div[class=' css-5cqaz8'] > div"));
        if (!ele.get(5).getText().isEmpty()) {
            action.moveToElement(ele.get(5)).pause(1000).click().build().perform();
            //Thread.sleep(2000);
        }
    }

    @Then("I click {string} at Order History Main Page")
    public void doClickCTAAtOrderHistoryMainPage(String CTA) {
        dashboardPage.clickCTAInOrderHistory(driver, CTA);
    }

    @Then("I verify the text {string} at Order History Main Page")
    public void verifyTextsAtOrderHistoryMainPage(String text) {
        dashboardPage.verifyTextAtMainPage(driver, text);
    }
}