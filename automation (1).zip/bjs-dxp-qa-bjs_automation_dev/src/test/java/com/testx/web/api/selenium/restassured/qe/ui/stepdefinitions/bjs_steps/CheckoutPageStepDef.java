package com.testx.web.api.selenium.restassured.qe.ui.stepdefinitions.bjs_steps;

import com.testx.web.api.selenium.restassured.qe.common.utils.config.Configuration;
import com.testx.web.api.selenium.restassured.qe.common.utils.config.ConfigurationManager;
import com.testx.web.api.selenium.restassured.qe.ui.context.Context;
import com.testx.web.api.selenium.restassured.qe.ui.context.TestContext;
import com.testx.web.api.selenium.restassured.qe.ui.pageobjects.BJsHomePage;
import com.testx.web.api.selenium.restassured.qe.ui.pageobjects.CheckoutPage;
import com.testx.web.api.selenium.restassured.qe.ui.pageobjects.ProductLandingPage;
import com.testx.web.api.selenium.restassured.qe.ui.stepdefinitions.BaseSetup;
import com.testx.web.api.selenium.restassured.qe.ui.stepdefinitions.prebuilt_steps.PrebuiltDataAssertionSteps;
import io.cucumber.java.en.And;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Then;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.util.List;
import java.util.Map;

public class CheckoutPageStepDef extends BaseSetup {

    private static final Logger LOGGER = LoggerFactory.getLogger(CheckoutPageStepDef.class);
    public static Configuration configuration = ConfigurationManager.getConfiguration();
    TestContext testContext;
    private CheckoutPage checkoutPage;
    private ProductLandingPage productLandingPage;
    public CheckoutPageStepDef(TestContext context, CheckoutPage checkoutPage, ProductLandingPage productLandingPage) {
        super(context);
        this.testContext = context;
        this.checkoutPage = checkoutPage;
        this.productLandingPage = productLandingPage;
    }

    @And("I add menu item {string} at Product Landing Page")
    public void selectMenuItem(String menuItem) throws InterruptedException {
        Thread.sleep(5000);
        productLandingPage.isClickMenuItem(driver, menuItem);
    }

    @Then("I select an option from Time DropDown on order Screen")
    public void iSelectOnTheDropdown() throws InterruptedException {
        Actions action = new Actions(driver);
        WebElement dp2 = driver.findElement(By.cssSelector("div[class=' css-ch4t1q']"));
        driverManagerUtils.findElementAndHighlight(driver,dp2,"green");
        dp2.click();
        //Thread.sleep(2000);
        List<WebElement> ele = driver.findElements(By.cssSelector("div[class=' css-5cqaz8'] > div"));
        if (!ele.get(5).getText().isEmpty()) {
            action.moveToElement(ele.get(5)).pause(1000).click().build().perform();
            //Thread.sleep(2000);
        }
    }

    @And("^I validate Products and price on Checkout page$")
    public void validateAtCheckout() {
        String item1_atCart = (String)testContext.scenarioContext.getContext(Context.PRODUCT_NAME1);
        String item2_atCart = (String)testContext.scenarioContext.getContext(Context.PRODUCT_NAME2);
        String priceOfItem1_atCart = (String)testContext.scenarioContext.getContext(Context.Price_PizzaMini);
        String priceOfItem2_atCart = (String)testContext.scenarioContext.getContext(Context.Price_BistroBurger);

        String product1 = checkoutPage.fetchProduct1_AtCheckout(driverManagerUtils,driver);
        char[] charArray1 = product1.toCharArray();
        product1 = product1.substring(0, charArray1.length-4);
        String product2 = checkoutPage.fetchProduct2_AtCheckout(driver);
        char[] charArray2 = product2.toCharArray();
        product2 = product2.substring(0, charArray2.length-4);
        String priceOfItem1_atCheckout = checkoutPage.fetchFirstItemPriceFromCheckout(driverManagerUtils,driver);
        String priceOfItem2_atCheckout = checkoutPage.fetchSecondItemPriceFromCheckout(driverManagerUtils,driver);

        String taxAmount = checkoutPage.fetchTaxFromCheckout(driver);
        String totalAmount = checkoutPage.fetchTotalAmountFromCheckout(driver);

        Assert.assertEquals("Product name "+ item1_atCart + " from Cart doesn't match with Product name "+product1+" from Checkout "
                , item1_atCart, product1);
        Assert.assertEquals("Product name "+ item2_atCart + " from Cart doesn't match with Product name "+product2+" from Checkout "
                , item2_atCart, product2);

        Assert.assertEquals("Price of product 1 "+ priceOfItem1_atCart + " from Cart doesn't match with price of product 1 at Checkout "+ priceOfItem1_atCheckout
                , priceOfItem1_atCart, priceOfItem1_atCheckout);
        Assert.assertEquals("Price of product 1 "+ priceOfItem2_atCart + " from Cart doesn't match with price of product 2 at Checkout "+ priceOfItem2_atCheckout
                , priceOfItem2_atCart, priceOfItem2_atCheckout);

        checkoutPage.validateTotalAmountBetweenCartAndCheckout(priceOfItem1_atCart, priceOfItem2_atCart, taxAmount, totalAmount);
    }

    @And("^I verify (.*) on Checkout page")
    public void verifyAtCheckout(String value) throws InterruptedException {
        Thread.sleep(5000);
        if(value == "Price")
        {
            String price_atCart = (String)testContext.scenarioContext.getContext(Context.Price);
            String priceOfItem_atCheckout = checkoutPage.fetchFirstItemPriceFromCheckout(driverManagerUtils,driver);
            Assert.assertEquals("Price of product 1 "+ price_atCart + " from Cart doesn't match with price of product 1 at Checkout "+ priceOfItem_atCheckout
                    , price_atCart, priceOfItem_atCheckout);
        }
        if(value == "Product") {
            String product_atCart = (String) testContext.scenarioContext.getContext(Context.Product);
            String productOfItem_atCheckout = checkoutPage.fetchProduct1_AtCheckout(driverManagerUtils,driver);
            Assert.assertEquals("Price of product 1 " + product_atCart + " from Cart doesn't match with price of product 1 at Checkout " + productOfItem_atCheckout
                    , product_atCart, productOfItem_atCheckout);
        }
    }
}
