package com.testx.web.api.selenium.restassured.qe.ui.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class SignUpPage extends AbstractPageObject {

    @FindBy(xpath = "//title[text()='Rewards']")
    public static WebElement signUpPageTitle;

    @FindBy(xpath = "//*[text()='*Preferred Location']/following-sibling::div//input")
    public static WebElement preferredLocation;

    @FindBy(xpath = "//*[@aria-expanded='true']")
    public static WebElement addressSuggestion;

    @FindBy(xpath = "//*[text()='GET MY PIZZA PERK']")
    public static WebElement getMyPizza;

    @FindBy(xpath = "//input[@aria-label='Email']")
    public static WebElement emailId;

    @FindBy(xpath = "//*[text()='LOG-IN']/ancestor::span/following-sibling::span[2]//*[contains(text(), 'SIGN UP')]")
    public static WebElement signUpHomePage;


}