package com.testx.web.api.selenium.restassured.qe.ui.stepdefinitions.bjs_steps;

import com.testx.web.api.selenium.restassured.qe.common.utils.config.Configuration;
import com.testx.web.api.selenium.restassured.qe.common.utils.config.ConfigurationManager;
import com.testx.web.api.selenium.restassured.qe.ui.context.TestContext;
import com.testx.web.api.selenium.restassured.qe.ui.pageobjects.FamilyMealDealPage;
import com.testx.web.api.selenium.restassured.qe.ui.stepdefinitions.BaseSetup;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FamilyMealDealPageStepDef extends BaseSetup {
    private static final Logger LOGGER = LoggerFactory.getLogger(ProductDetailPageStepDef.class);
    public static Configuration configuration = ConfigurationManager.getConfiguration();
    TestContext testContext;
    private FamilyMealDealPage FamilyMealDealPage;
    public FamilyMealDealPageStepDef(TestContext context, FamilyMealDealPage FamilyMealDealPage) {
        super(context);
        this.testContext = context;
        this.FamilyMealDealPage = FamilyMealDealPage;
    }

}
