package com.testx.web.api.selenium.restassured.qe.ui.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LocationPage extends AbstractPageObject {

    @FindBy(xpath = "//*[text()='Edit']")
    public static WebElement EditButton;

    @FindBy(xpath = "//p[text()='Dine In']")
    public static WebElement DineInOrderButton;

    @FindBy(id="search-input")
    public static WebElement searchbox;

    @FindBy(xpath = "//div[contains(text(),' results near')]")
    public static WebElement resultMessage;

    @FindBy(xpath = "(//*[text()='ORDER AHEAD'])[1]")
    public static WebElement orderCTA;

    @FindBy(xpath = "(//*[text()='Join Waitlist'])[1]")
    public static WebElement joinWaitListCTA;

    @FindBy(id="tabs-:r2:--tab-1")
    public static WebElement TakeoutOrderButton;

    @FindBy(xpath="//li[text()='Sacramento, CA, USA']")
    public static WebElement cityName;

    @FindBy(xpath="//li[text()='Laguna Hills, CA, USA']")
    public static WebElement cityName1;

    @FindBy(xpath="//li[text()='12300 Bermuda Road, Henderson, NV, USA']")
    public static WebElement deliverycityName;

    @FindBy(xpath = "(//*[text()='ORDER TAKEOUT'])[1]")
    public static WebElement takeoutCTA;

    @FindBy(xpath = "(//p[text()='LOCATION DETAILS'])[1]")
    public static WebElement locationDetailsCTA;

    @FindBy(xpath = "//p[text()='Delivery']")
    public static WebElement deliverOrderButton;

    @FindBy(xpath = "//p[text()='ORDER DELIVERY']")
    public static WebElement orderDeliveryCTA;

    @FindBy(xpath = "//span[contains(text(),'Continue')]")
    public static WebElement continueBtn;

}
