package com.testx.web.api.selenium.restassured.qe.ui.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.List;

public class CateringPage extends AbstractPageObject{

    @FindBy(xpath = "//*[@type='button']//*[contains(text(),'Boxed Meals')]")
    public static WebElement boxedMealsCategory;

    @FindBy(xpath = "//*[contains(@href,'specialty-entree-box')]//*[contains(text(),'Specialty')]")
    public static WebElement specialtyEntreeBox;

    @FindBy(xpath = "//*[contains(text(),'Minimum of 8 boxes required')]")
    public static WebElement minimumOrder;

    @FindBy(xpath = "//*[contains(text(),'any variety')]")
    public static WebElement anyVarietyText;

    @FindBy(xpath = "//p[contains(text(),'Sandwich Choice')]")
    public static WebElement sandwichChoice;

    @FindBy(xpath = "//span[contains(text(),'Specialty Entree Box')]")
    public static WebElement specialtyBox;

    @FindBy(xpath = "//*[@role='button']//*[contains(text(),'Pasta')]")
    public static WebElement pastaBoxTab;

    @FindBy(xpath = "//span[contains(text(),'Pasta Box')]")
    public static WebElement pastaBox;

    @FindBy(xpath = "//*[@role='button']//*[contains(text(),'Pizza')]")
    public static WebElement pizzaBoxTab;

    @FindBy(xpath = "//span[contains(text(),'Pizza')]")
    public static WebElement pizzaBox;

    @FindBy(xpath = "//*[@role='button']//*[contains(text(),'Sandwich')]")
    public static WebElement sandwichBoxTab;

    @FindBy(xpath = "//span[contains(text(),'Sandwich')]")
    public static WebElement sandwichBox;

    @FindBy(xpath = "//*[@role='button']/descendant::div[4]")
    public static List<WebElement> pricesCals;

    @FindBy(xpath = "//*[contains(text(),'Choose Your')]")
    public static WebElement chooseYourSandwich;

    @FindBy(xpath = "//*[contains(@id,'accordion-panel')]//*[contains(text(),'Mediterranean')]")
    public static WebElement mediterraneanOption;

    @FindBy(xpath = "//*[contains(@id,'collapsible-content')]//*[contains(text(),'Included')]")
    public static List<WebElement> includedTag;

    @FindBy(xpath = "//*[contains(@type,'button')]//*[contains(text(),'ADD')]")
    public static WebElement addToOrder;

    @FindBy(xpath = "//*[contains(@type,'button')]//*[contains(text(),'OK')]")
    public static WebElement okButton;

    @FindBy(xpath = "//span[contains(text(),'Mediterranean Chicken')]")
    public static WebElement sandwichSelection;

    @FindBy(xpath = "//p[normalize-space()='Mediterranean Chicken']")
    public static WebElement sandwichOnMiniCart;

    @FindBy(xpath = "//*[contains(@id,'content')]//img[contains(@data-src,'mediterranean-chicken')]")
    public static WebElement mediterraneanImageOnCart;

    @FindBy(xpath = "//*[contains(@aria-label,'Shopping Cart')]")
    public static WebElement cateringCart;

    @FindBy(xpath = "//p[contains(text(),'Extras')]")
    public static WebElement extrasButton;

    @FindBy(xpath = "//h3[contains(text(),'Sandwich Platter')]")
    public static WebElement sandwichPlattersLabel;

    @FindBy(xpath = "//p[normalize-space()='Sandwich Platter']")
    public static WebElement sandwichPlattersItem;

    @FindBy(xpath = "//span[normalize-space()='Sandwich Platter']")
    public static WebElement sandwichPlattersBannerHeading;

    @FindBy(css = "div[role='img'] > div > div > div+div > h2")
    public static WebElement sandwichPlattersBannerHeadingCollapse;

    @FindBy(css = "div[role='img'] > div+div > div > div > div > h2+p")
    public static WebElement sandwichPlattersBannerPrice;

    @FindBy(css = "div[role='img'] > div > div > div+div > p")
    public static WebElement sandwichPlattersBannerPriceCollapse;

    @FindBy(css = "div[role='img'] > div+div > div > div+div > div > p:nth-child(1)")
    public static WebElement sandwichPlattersBannerServes;

    @FindBy(css = "div[role='img'] > div+div > div > div+div > div > p:nth-child(2)")
    public static WebElement sandwichPlattersBannerCopy;

    @FindBy(css = "div[role='img']")
    public static WebElement sandwichPlattersBannerImage;

    @FindBy(name = "arrow-left")
    public static WebElement arrowLeftButton;

    @FindBy(css = "div[id='Sandwich Choices']  button")
    public static WebElement chevron;

    @FindBy(css = "div[id='Sandwich Choices']  div > div > div > p:nth-child(1)")
    public static WebElement sandwichChoicesHeading;

    @FindBy(css = "div[id='Sandwich Choices']  div > div > div > p:nth-child(2)")
    public static WebElement sandwichChoicesSubHeading;

    @FindBy(css = "div[id='Sandwich Choices']  div > div > span > p")
    public static WebElement statusTitle;

    @FindBy(css = "div[id='Sandwich Choices'] div[role='region'] > div > div")
    public static List<WebElement> sandwichList;

    @FindBy(css = "div[id='Sandwich Choices'] div[role='region'] > div > div label[id='2047']")
    public static WebElement sandwichListFirst;
    @FindBy(css = "div[id='Sandwich Choices'] div[role='region'] > div > div label[id='2049']")
    public static WebElement sandwichListSecond;
    @FindBy(css = "div[id='Sandwich Choices'] div[role='region'] > div > div label[id='2050']")
    public static WebElement sandwichListThird;

    @FindBy(css = "span[direction='horizontal']")
    public static WebElement itemStepper;
    @FindBy(css = "span[direction='horizontal']")
    public static List<WebElement> itemSteppers;

    @FindBy(css = "button[data-testid='add-to-cart']")
    public static WebElement saveSelectionButton;

    @FindBy(css = "input[value='63818']")
    public static WebElement secondChoice;
    @FindBy(css = "input[value='63817']")
    public static WebElement firstChoice;

    @FindBy(css = "div[class='items '] > div")
    public static List<WebElement> miniSummaryList;

    @FindBy(xpath = "//a[text()='CATERING']")
    public static WebElement catering;

    @FindBy(xpath = "//img[@alt='Hero Banner Alt Text']")
    public static WebElement heroBanner;

    @FindBy(xpath = "//p[contains(text(), 'Whether it’s a lunch meeting for 10 or a party of 100')]")
    public static WebElement Description;

    @FindBy(xpath = "//*[text()='Catering FAQs']")
    public static WebElement faqsCTA;

    @FindBy(xpath = "//p[text()='CATERING']")
    public static WebElement cateringHead;

    @FindBy(xpath = "//p[text()='Brewhouse Combinations']")
    public static WebElement brewhouseComb;

    @FindBy(xpath = "//p[text()='Boxed Meals']")
    public static WebElement boxedMeal;

    @FindBy(xpath = "//p[text()='Appetizer Platters']")
    public static WebElement appetizerPlatter;

    @FindBy(xpath = "//p[text()='Specialty Entree Platters']")
    public static WebElement specialtyEntree;

    @FindBy(xpath = "//p[text()='Extras']")
    public static WebElement extras;

    @FindBy(xpath = "//p[text()='HB - Beach Blvd']")
    public static WebElement testLocation;

    @FindBy(xpath = "//a[text()='catering@bjsrestaurants.com']")
    public static WebElement email;

    @FindBy(xpath = "Catering must be ordered in advance")
    public static WebElement cateringText;

    @FindBy(xpath = "//a[text()='FAQs']")
    public static WebElement faqsLink;

    @FindBy(xpath = "//div[text()='* All calories are approximate by serving']")
    public static WebElement servingText;

    @FindBy(xpath = "//p[contains(text(),'.  Provide 2 hour notice for orders up to $500 and')]")
    public static WebElement advanceText;

    @FindBy(xpath = "//button[contains(@aria-label,'BACK TO TOP')]")
    public static WebElement backCTA;

    @FindBy(xpath = "//P[text()='Brewhouse Combinations']")
    public static WebElement brewhouseCombo;

    @FindBy(xpath = "//P[text()='Packages ideal for any occasion']")
    public static WebElement brewhouseComboDesc;

    @FindBy(xpath = "//p[text()='4 items']")
    public static WebElement itemCount;

    @FindBy(xpath = "//div[text()='Packages ideal for any occasion.']")
    public static WebElement packagesDesc;

    @FindBy(xpath = "//img[@alt='Specialty Entrée Combo']")
    public static WebElement heroImage;

    @FindBy(xpath = "//p[text()='$162.95']")
    public static WebElement itemPrice;

    @FindBy(xpath = "//p[text()='Fan Favorite']")
    public static WebElement fanFavoriteTag;

    @FindBy(xpath = "//h3[text()='Slow-Roasted Tri-Tip*']")
    public static WebElement slowRoasted;

    @FindBy(xpath = "//h3[text()=' Atlantic Salmon*']")
    public static WebElement atlanticSal;

    @FindBy(xpath = "//span[text()='Save Selection']")
    public static WebElement saveSelect;

    @FindBy(xpath = "//h3[text()='Caesar Salad']")
    public static WebElement caesarSalad;

    @FindBy(xpath = "//p[text()='ADD TO ORDER']")
    public static WebElement addOrderCTA;

    @FindBy(xpath = "//p[text()='CUSTOMIZE']")
    public static WebElement customizeCTA;

    @FindBy(xpath = "//p[text()='Sold Out']")
    public static WebElement soldOutText;

    @FindBy(xpath = "//img[@alt='Sandwich Combo']")
    public static WebElement sandwichCombo;

    @FindBy(xpath = "//button[@name='arrow-left']//span[@role='img']")
    public static WebElement backButton;

    @FindBy(xpath = "//p[contains(text(),'Kick off your luncheon right with any of our appet')]")
    public static WebElement endText;

    @FindBy(xpath = "//p[contains(text(),'There’s enough stress with everyday work life; let')]")
    public static WebElement endScrollText;

    @FindBy(xpath = "//p[contains(text(), 'BJ’s Restaurant & Brew')]")
    public static WebElement scrollText;

    @FindBy(xpath = "//p[contains(text(), 'Our delectable restaurant and taphouse is a favorite across the')]")
    public static WebElement endTextLastPart;

    @FindBy(xpath = "//button[@aria-label='BACK TO TOP']")
    public static WebElement backToTop;

    @FindBy(xpath = "//p[text()='Brewhouse Combinations']")
    public static WebElement brewHouseCombinations;

    @FindBy(xpath = "//p[text()='Specialty Entrée Combo']")
    public static WebElement specialtyEntreeCombo;

    @FindBy(xpath = "//span[text()='Specialty Entrée Combo']//parent::h2")
    public static WebElement specialtyEntreeComboItemTitle;

    @FindBy(xpath = "//p[text()='Serves  12']")
    public static WebElement RecommendedGuestCopyArea;

    @FindBy(xpath = "//p[text()='2 Entrees | 1 Salad | 12 Garlic Knots  ']")
    public static WebElement copyAreaDescription;

    @FindBy(xpath = "//p[text()='Entree Choice (0 of 2)']")
    public static WebElement EntreesItemHeading;

    @FindBy(xpath = "//*[text()='Salad Choice (0 of 1)']")
    public static WebElement saladItemHeading;

    @FindBy(xpath = "//p[text()='Pick 2 Entrees']")
    public static WebElement entreeSelectionRequirement;

    @FindBy(xpath = "//*[text()='Pick 1 Salad']")
    public static WebElement saladSelectionRequirement;

    @FindBy(xpath = "//h3[text()='Slow-Roasted Tri-Tip*']")
    public static WebElement slowRoastedTriTip;

    @FindBy(xpath = "//h3[text()=' Atlantic Salmon*']")
    public static WebElement atlanticSalmon;

    @FindBy(xpath = "//*[text()='Customizing:']")
    public static WebElement customizingField;

    @FindBy(xpath = "//div[@variant='solid']")
    public static WebElement saveSelectButton;

    @FindBy(xpath = "//*[@id='accordion-button-:r1e:']/div/div/span/p")
    public static WebElement entreeStatusTile;

    @FindBy(xpath = "//*[text()='Barbeque Chicken Chopped Salad']")
    public static WebElement barbequeChickenChoppedSalad;

    @FindBy(xpath = "//*[text()='Garlic Knots (1 of 1)']")
    public static WebElement garlicKnots;

    @FindBy(xpath = "//*[contains(text(),'Pasta Box')]")
    public static WebElement pastaBoxCTA;

    @FindBy(xpath = "//h3[contains(text(),'Grilled Chicken Alfredo')]")
    public static WebElement GrilledChickenPDP;

    @FindBy(xpath = "//h3[contains(text(),'Caesar Salad')]")
    public static WebElement CaesarPDP;


}