package com.testx.web.api.selenium.restassured.qe.api.stepdefs;

import com.testx.web.api.selenium.restassured.qe.api.httpservicemanager.HttpResponseManager;
import com.testx.web.api.selenium.restassured.qe.api.httpservicemanager.RestRequestManager;
import com.testx.web.api.selenium.restassured.qe.api.enums.ApiContext;
import com.testx.web.api.selenium.restassured.qe.api.util.ApiUtilManager;
import com.testx.web.api.selenium.restassured.qe.common.utils.config.Configuration;
import com.testx.web.api.selenium.restassured.qe.common.utils.config.ConfigurationManager;
import io.cucumber.java.en.And;
import io.cucumber.java.en.When;

public class CommonWhenTestSteps {

    HttpResponseManager httpResponseManager;
    TestManagerContext testManagerContext;
    RestRequestManager restRequestManager;
    public Configuration configuration;

    public CommonWhenTestSteps(TestManagerContext context) {
        testManagerContext = context;
        httpResponseManager = testManagerContext.getHttpResponse();
        restRequestManager = testManagerContext.getRestRequest();
        configuration = ConfigurationManager.getConfiguration();
    }

    @When("^the client performs (.+) request on API \"(.+)\"$")
    public void perform_Http_Request(String httpMethod, String url) throws Throwable {
        httpResponseManager.setResponsePrefix("");
        ApiUtilManager apiUtilManager = new ApiUtilManager();
        httpResponseManager.setReponse(httpResponseManager.doRequest(httpMethod, apiUtilManager.getBasePath(url)));
    }

    @When("I call method {string}")
    public void iCallMethodPOST(String httpMethod) throws Exception {
        httpResponseManager.setResponsePrefix("");
        String basePath = configuration.apiUrl();
        httpResponseManager.setReponse(httpResponseManager.doRequest(httpMethod, basePath));
    }

    @And("I get the response")
    public void iGetTheResponse() {
        testManagerContext
                .getScenarioContext()
                .setContext(ApiContext.RESPONSE_BODY, httpResponseManager.getResponse().asString());
    }

    @And("I save the initial response")
    public void iSaveTheInitialResponse() {
        testManagerContext
                .getScenarioContext()
                .setContext(ApiContext.INITIAL_RESPONSE_BODY, httpResponseManager.getResponse().asString());
    }
}
