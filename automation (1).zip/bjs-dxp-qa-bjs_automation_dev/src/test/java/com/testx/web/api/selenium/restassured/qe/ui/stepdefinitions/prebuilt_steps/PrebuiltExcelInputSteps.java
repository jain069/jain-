package com.testx.web.api.selenium.restassured.qe.ui.stepdefinitions.prebuilt_steps;

import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;
import com.testx.web.api.selenium.restassured.qe.ui.context.TestContext;
import com.testx.web.api.selenium.restassured.qe.ui.stepdefinitions.BaseSetup;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.When;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Duration;
import java.util.List;
import java.util.Map;

public class PrebuiltExcelInputSteps extends BaseSetup {

    private static final Logger LOGGER = LoggerFactory.getLogger(PrebuiltBrowserSteps.class);
    TestContext testContext;

    public PrebuiltExcelInputSteps(TestContext context) {
        super(context);
        this.testContext = context;
    }

    @When("^I enter the data for the following fields from the excel file (.*)$")
    public void iEnterValuesInToTheFieldsOnThePage(String excelFileData, DataTable dataTable) throws FilloException,InterruptedException {
        String envURL = driver.getCurrentUrl();
        String[] urlParts = envURL.split("[.]");
        String ProjectWorkingDirectory = System.getProperty("user.dir");
        String fileDataPath = ProjectWorkingDirectory + "/src/test/resources/ui/excel_data/";
        String[] parts = excelFileData.split(":");
        String excelFileName = parts[0] + "_" + urlParts[1];
        String excelFileSheetName = parts[1];
        String excelFileRowID = parts[2];
        Fillo fillo = new Fillo();
        Connection connection = fillo.getConnection(fileDataPath + excelFileName + ".xlsx");
        List<Map<String, String>> rows = dataTable.asMaps(String.class, String.class);
        Recordset recordset = null;
        for (Map<String, String> column : rows) {
            String fieldName = column.get("FieldName");
            String pageClassName = column.get("PageName");
            String strQuery = String.format("Select * from %s where TEST_ID='%s'", excelFileSheetName, excelFileRowID);
            recordset = connection.executeQuery(strQuery);
            while (recordset.next()) {
                WebElement webElement = loadWebElement(fieldName, pageClassName);
                driverManagerUtils.enterText(driver, webElement, recordset.getField(fieldName));
            }
        }
        driver.findElement(By.xpath("//html")).click();
        assert recordset != null;
        recordset.close();
        connection.close();
        Thread.sleep(5000);
    }

    @When("^I fetch item name from the excel and add the item to the cart (.*)$")
    public void iCreateXpathToAddItemToCart(String excelFileData, DataTable dataTable) throws Exception {
        String envURL = driver.getCurrentUrl();
        String[] urlParts = envURL.split("[.]");
        String ProjectWorkingDirectory = System.getProperty("user.dir");
        String fileDataPath = ProjectWorkingDirectory + "/src/test/resources/ui/excel_data/";
        String[] parts = excelFileData.split(":");
        String excelFileName = parts[0] + "_" + urlParts[1];
        String excelFileSheetName = parts[1];
        String excelFileRowID = parts[2];
        Fillo fillo = new Fillo();
        Connection connection = fillo.getConnection(fileDataPath + excelFileName + ".xlsx");
        List<Map<String, String>> rows = dataTable.asMaps(String.class, String.class);
        Recordset recordset = null;
        for (Map<String, String> column : rows) {
            String fieldName = column.get("FieldName");
            String pageClassName = column.get("PageName");
            String strQuery = String.format("Select * from %s where TEST_ID='%s'", excelFileSheetName, excelFileRowID);
            recordset = connection.executeQuery(strQuery);
            while (recordset.next()) {
                // String beforePath = "(//button[contains(@aria-label, '";
                //  String afterPath = "')])[1]";
                String menuItem = recordset.getField(fieldName);
                String strXpath = String.format("(//button[contains(@aria-label, \"%s\")])[1]", menuItem);
                //  System.out.println("Xpath ---- "+strXpath);
                // String addItem = beforePath + menuItem + afterPath;
//                Thread.sleep(5000);
                WebElement element = driver.findElement(By.xpath(strXpath));
                driverManagerUtils.fluentWaitForElement(driver, element);
                element.click();
                Thread.sleep(5000);
                if (driver.getCurrentUrl().contains("menu-item")) {
                    Thread.sleep(5000);
                    try {
                        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
                        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[text()='*Required']")));
                        List<WebElement> allRequiredOptions = driver.findElements(By.xpath("//*[text()='*Required']/following::input[@type='radio'][1]/following::span[1]"));
                        for (WebElement option : allRequiredOptions) {
                            option.click();
                        }
                        driver.findElement(By.xpath("//*[@data-testid='add-to-cart']")).click();
                    } catch (TimeoutException te) {
                        driver.findElement(By.xpath("//*[@data-testid='add-to-cart']")).click();
                    }
                }
                Thread.sleep(5000);
            }
        }
        assert recordset != null;
        recordset.close();
        connection.close();
    }

    @When("^I fetch item name from the excel sheet (.*)$")
    public void iCreateXpath(String excelFileData, DataTable dataTable) throws Exception {
        String envURL = driver.getCurrentUrl();
        String[] urlParts = envURL.split("[.]");
        String ProjectWorkingDirectory = System.getProperty("user.dir");
        String fileDataPath = ProjectWorkingDirectory + "/src/test/resources/ui/excel_data/";
        String[] parts = excelFileData.split(":");
        String excelFileName = parts[0] + "_" + urlParts[1];
        String excelFileSheetName = parts[1];
        String excelFileRowID = parts[2];
        Fillo fillo = new Fillo();
        Connection connection = fillo.getConnection(fileDataPath + excelFileName + ".xlsx");
        List<Map<String, String>> rows = dataTable.asMaps(String.class, String.class);
        Recordset recordset = null;
        for (Map<String, String> column : rows) {
            String fieldName = column.get("FieldName");
            String pageClassName = column.get("PageName");
            String strQuery = String.format("Select * from %s where TEST_ID='%s'", excelFileSheetName, excelFileRowID);
            recordset = connection.executeQuery(strQuery);
            while (recordset.next()) {
                String beforePath = "(//*[contains(text(), '";
                String afterPath = "')])[1]";
                String menuItem = recordset.getField(fieldName);
                String addItem = beforePath + menuItem + afterPath;
                Thread.sleep(3000);
                WebElement element = driver.findElement(By.xpath(addItem));
                driverManagerUtils.fluentWaitForElement(driver, element);
                if (!driver.getCurrentUrl().contains("menu")) {
                    element.click();
                    Thread.sleep(2000);
                    // adding code to handle the location popup in PLP page
                    String confirmLocCTA = "//*[text()='Continue Ordering']";
                    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
                    wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(confirmLocCTA)));
                    driverManagerUtils.clickElement(driver, driver.findElement(By.xpath(confirmLocCTA)));
                    Thread.sleep(3000);
                    driverManagerUtils.switchToParentFrame();
                } else {
                    element.click();
                    Thread.sleep(2000);
                }

            }
        }
        assert recordset != null;
        recordset.close();
        connection.close();
    }
}
