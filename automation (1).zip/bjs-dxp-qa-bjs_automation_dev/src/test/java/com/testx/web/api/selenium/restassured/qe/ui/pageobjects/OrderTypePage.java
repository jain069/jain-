package com.testx.web.api.selenium.restassured.qe.ui.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class OrderTypePage extends AbstractPageObject {

    @FindBy(xpath = "//*[text()='Takeout']")
    public static WebElement takeOutTab;

    @FindBy(xpath = "//*[text()='Dine In']")
    public static WebElement dineInTab;

    @FindBy(xpath = "//*[text()='Delivery']")
    public static WebElement deliveryTab;

    @FindBy(xpath = "//button[@data-testid='icon-button'][1]")
    public static WebElement backButton;

    @FindBy(xpath = "//button[@data-testid='icon-button'][2]")
    public static WebElement cancelButton;

    @FindBy(xpath = "//*[@role='group']")
    public static WebElement findBJsByStateDropdown;

    @FindBy(id = "field-:r3s:")
    public static WebElement findBJsByStateInput;

    @FindBy(xpath = "//div[@tabindex='-1'][5]")
    public static WebElement californiaState;

    @FindBy(xpath = "//*[text()='ORDER AHEAD']")
    public static WebElement orderAheadButton;

    @FindBy(xpath = "//label[contains(text(),'Date')]//following::div")
    public static WebElement dateDropdown;

    @FindBy(xpath = "//div[@tabindex='-1']")
    public static WebElement TodayDate;

    @FindBy(xpath = "//label[contains(text(),'Time')]//following::div")
    public static WebElement timeDropdown;

    @FindBy(xpath = "//div[@tabindex='-1']")
    public static WebElement asapTime;

    @FindBy(xpath = "//label[contains(text(),'Table for')]//following::div")
    public static WebElement tableForDropdown;

    @FindBy(xpath = "//div[@tabindex='-1']")
    public static WebElement tableForValue;

    @FindBy(css = "button[aria-label='START ADDING TO ORDER']")
    public static WebElement startAddingToOrderBtn;

    @FindBy(xpath = "//*[text()='START ADDING TO ORDER']")
    public static WebElement startAddingToOrderCTA;

    @FindBy(css = "button[aria-label='Continue your order']")
    public static WebElement continueYourOrderCTA;

    @FindBy(xpath = "//*[text()='Join Waitlist']")
    public static WebElement joinWaitlistButton;

    @FindBy(xpath = "//label[contains(text(),'Party of')]//following::div")
    public static WebElement partyOfDropdown;

    @FindBy(xpath = "//div[contains(text(),'3')]")
    public static WebElement partyOf3PplValue;

    @FindBy(xpath = "//p[contains(text(),'Name')]//preceding-sibling::input")
    public static WebElement nameTextbox;

    @FindBy(xpath = "//p[contains(text(),'Phone')]//preceding-sibling::input")
    public static WebElement phoneTextbox;

    @FindBy(xpath = "//p[contains(text(),'Email')]//preceding-sibling::input")
    public static WebElement emailTextbox;

    @FindBy(xpath = "//p[contains(text(),'Special')]//preceding-sibling::input")
    public static WebElement specialRequestTextbox;

    @FindBy(xpath = "//*[text()='Save My Spot']")
    public static WebElement saveMySpotBtn;

    @FindBy(id = "search-input")
    public static WebElement searchBox;

    @FindBy(xpath = "//*[@class='sc-ktCSKO jFDAns']//following-sibling::ul")
    public static WebElement resultDropDown;

    @FindBy(xpath = "(//button[contains(@aria-label,'Label Text')])[1]")
    public static WebElement orderTakeOutBtn;

    @FindBy(xpath = "//*[text()='ORDER DELIVERY']")
    public static WebElement orderDeliveryBtn;

    @FindBy(xpath = "//*[text()='Date']/following-sibling::div//input")
    public static WebElement dateDropDown;

    @FindBy(xpath = "//*[text()='Time']/following-sibling::div//input")
    public static WebElement timeDropDown;

    @FindBy(css = "button[class='chakra-button location-alert-change css-62uucc']")
    public static WebElement continueBtn;

    @FindBy(xpath = "//span[text()='Dine In']")
    public static WebElement dineInText;

    @FindBy(xpath = "//span[text()='Time']")
    public static WebElement timeText;

    @FindBy(xpath = "//h1[text()='Huntsville']")
    public static WebElement huntsvilleHeader;

    @FindBy(xpath = "//p[text()='LOCATION DETAILS']")
    public static WebElement locDetailsCTA;

    @FindBy(xpath = "//span[text()=' | Opens at 11:00 am']")
    public static WebElement locOpenTime;

    @FindBy(xpath = "//p[text()='RESERVATIONS']")
    public static WebElement reservationCTA;

    @FindBy(xpath = "//a[text()='Return to Search Results ']")
    public static WebElement retuenSearchResCTA;

    @FindBy(xpath = "//*[text()='Change Location']")
    public static WebElement changeLocationButton;

    @FindBy(xpath = "//*[text()='Yes, Change Location']")
    public static WebElement changeLocation;

    @FindBy(xpath = "//*[text()='Dine In']")
    public static WebElement orderTypeDineIn;

    @FindBy(xpath = "//*[text()='Yes, Change Location']")
    public static WebElement yesChangeLocCTA;

    @FindBy(xpath = "//*[text()='No, Keep This Location']")
    public static WebElement NochangeLocCTA;

    @FindBy(css = "button[aria-label='START ADDING TO ORDER']")
    public static WebElement continueLocCTA;

    @FindBy(xpath = "//*[text()='Find a Restaurant']")
    public static WebElement findARestaurant;

    @FindBy(xpath = "//*[@data-testid='clear-input-btn']")
    public static WebElement buttonClose;

    @FindBy(xpath = "//p[text()='Dine In']")
    public static WebElement textDineIn;

    @FindBy(xpath = "//*[contains(@id, 'react-select-7')]/parent::*//input")
    public static WebElement Date;

    @FindBy(xpath = "//*[contains(@id, 'react-select-8')]/parent::*//input")
    public static WebElement Time;

    @FindBy(xpath = "//*[text()='*Date']/following-sibling::div//input")
    public static WebElement dateDrop;

    @FindBy(xpath = "//*[text()='*Time']/following-sibling::div//input")
    public static WebElement timeDrop;

    @FindBy(xpath = "//*[text()='*Table for']/following-sibling::div//input")
    public static WebElement tableDrop;

    @FindBy(xpath = "//*[contains(text(), 'Continue')]")
    public static WebElement continueYourOrder;

    @FindBy(xpath = "//p[text()='Continue your checkout']")
    public static WebElement continueYourCheckout;

    @FindBy(xpath = "//span[@class='icon-bjs-clock ']//following::p[1]")
    public static WebElement time;

    @FindBy(xpath = "//*[contains(text(), 'Change Location')]//preceding::hr//following::span[1]")
    public static WebElement restaurantStatus;

}