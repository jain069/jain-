package com.testx.web.api.selenium.restassured.qe.api.constants;

public class Headers {

  public static final String COMMON_HEADERS = "headers";
}
