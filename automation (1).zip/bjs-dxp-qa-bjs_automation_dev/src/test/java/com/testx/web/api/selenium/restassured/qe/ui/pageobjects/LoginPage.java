package com.testx.web.api.selenium.restassured.qe.ui.pageobjects;


import org.openqa.selenium.*;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class LoginPage extends AbstractPageObject {

    Actions action;
    @FindBy(css = "input[type*=email]")
    public static WebElement usernameInput;

    @FindBy(css = "input[type*=password]")
    public static WebElement passwordInput;

    @FindBy(xpath = "//a[text()='LOG-IN']")
    public static WebElement loginButtonHomepage;

    @FindBy(xpath = "//*[text()='BJ’s Premier Reward PLUS']")
    public static WebElement BJSTitle;

    @FindBy(xpath = "//*[text()='Log in to earn and redeem rewards']")
    public static WebElement bodyCopy;

    @FindBy(xpath = "//*[@type='button']//child::span")
    public static WebElement CloseButton;

    @FindBy(css = "button[class*=login-button]")
    public static WebElement loginButton;

    @FindBy(css = "h3[data-test='error']")
    public static WebElement loginButtonError;

    @FindBy(xpath = "//*[@aria-label='Show password']")
    public static WebElement showPassWord;

    @FindBy(xpath = "//*[@class='icon-bjs-hide ']")
    public static WebElement hidePassWord;

    @FindBy(xpath = "//*[text()='Email not found, please try again']")
    public static WebElement emailErrorMsg;

    @FindBy(xpath = "//*[text()='credentials combination not valid']")
    public static WebElement passwordErrorMsg;

    @FindBy(xpath = "//*[text()='Log In']")
    public static WebElement LoginButton;

    @FindBy(xpath = "//a[text()='Forgot email or password?']")
    public static WebElement forgotPassWordLink;

    @FindBy(xpath = "//a[text()='Create an account']")
    public static WebElement createAccountLink;

    @FindBy(xpath = "//*[@class='chakra-text user-name css-ykew9n' and contains(text(),'Hi, ')]")
    public static WebElement welcomMessage;

    //Sign-up - User registration

    @FindBy(xpath = "//title[text()='Rewards']")
    public static WebElement signUpPageTitle;

    @FindBy(xpath = "//*[text()='Account Information']")
    public static WebElement textAccInfo;

    @FindBy(xpath = "//*[@aria-label='First name']")
    public static WebElement FirstName;

    @FindBy(xpath = "//*[@aria-label='Last name']")
    public static WebElement LastName;

    @FindBy(xpath = "//*[@aria-label='Email']")
    public static WebElement Email;

    @FindBy(xpath = "//*[@aria-label='Date of birth']")
    public static WebElement DoB;

    @FindBy(xpath = "//*[@aria-label='Address']")
    public static WebElement Address;

    @FindBy(xpath = "//*[@aria-label='Phone']")
    public static WebElement Phone;

    @FindBy(xpath = "//*[text()='Create Password']")
    public static WebElement textCreatePassword;

    @FindBy(xpath = "//*[@aria-label='Password']")
    public static WebElement Password;

    @FindBy(xpath = "//*[@aria-label='Confirm Password']")
    public static WebElement ConfirmPassword;

    @FindBy(xpath = "//*[contains(@id, '-live-region')]/following-sibling::div")
    public static WebElement dropDownLocation;

    @FindBy(xpath = "//*[contains(text(), 'Privacy Policy.')]/ancestor::span/preceding-sibling::span")
    public static WebElement checkBox;

    @FindBy(xpath = "//*[text()='Create Account']")
    public static WebElement buttonCreateAccount;

    @FindBy(xpath = "//img[@alt='Hero Alt text']")
    public static WebElement confirmationHeroBanner;

    @FindBy(xpath = "//*[text()='Registration Complete']")
    public static WebElement textRegistrationComplete;

    @FindBy(xpath = "//*[contains(text(), 'PREMIER REWARDS PLUS')]")
    public static WebElement sideRailHeader;

    @FindBy(xpath = "//*[contains(text(), 'When you join Premier Rewards Plus,')]")
    public static WebElement sideRailSubHeader;

    @FindBy(xpath = "//img[contains(@class, 'lazy s')]")
    public static WebElement sideRailHeroBanner;

    @FindBy(xpath = "//*[text()='Log in to earn and redeem rewards']")
    public static WebElement textBanner;

    @FindBy(xpath = "//*[text()='Forgot email or password?']")
    public static WebElement forgotEmailOrPassword;

    @FindBy(xpath = "//span[@class='path1']")
    public static WebElement Logo;

    @FindBy(xpath = "//*[text()='Account Assistance']")
    public static WebElement forgotPasswordHeader;

    @FindBy(xpath = "//*[contains(@class, 'arrow-left')]")
    public static WebElement backArrow;

    @FindBy(xpath = "//*[text()='BJ’s Premier Reward PLUS']")
    public static WebElement bjsLoginHeader;

    @FindBy(xpath = "//*[contains(text(), 'Enter your email and we will send')]")
    public static WebElement forgotPasswordDescription;

    @FindBy(css = "input[data-testid*=email]")
    public static WebElement emailForgotPassword;

    @FindBy(xpath = "//*[contains(text(), 'Please provide a valid')]")
    public static WebElement invalidEmailAlert;

    @FindBy(xpath = "//*[contains(@aria-label, 'close icon')]")
    public static WebElement xButtonForgot;

    @FindBy(xpath = "//*[contains(@aria-label, 'send reset')]")
    public static WebElement sendResetPassword;

    @FindBy(xpath = "//*[contains(text(), 'There is no account')]")
    public static WebElement noAccountAssociated;

    @FindBy(xpath = "//*[contains(text(), 'Reset Password Link Sent')]")
    public static WebElement confirmationHeader;

    @FindBy(xpath = "//*[contains(text(), 'We emailed a confirmation')]")
    public static WebElement linkConfirmation;

    @FindBy(xpath = "//button[contains(@aria-label, 'Resend Link')]")
    public static WebElement resendLinkButton;

    @FindBy(xpath = "//*[contains(@class, 'alert-content')]//div")
    public static WebElement linkSentAlert;

    @FindBy(xpath = "//*[@data-testid='clear-input-btn']")
    public static WebElement cancelButton;

    public void selectAutoSuggestedTextBox(WebDriver driver, String text, WebElement element) {
        try {
            Thread.sleep(5000);
            action = new Actions(driver);
            element.click();
            element.sendKeys(text);
            Thread.sleep(3000);
            WebElement ele = driver.findElement(By.xpath("//*[@class='list']//li"));
            if (ele.getText().equalsIgnoreCase(text)) {
                action.moveToElement(ele).pause(2000).click().build().perform();
                Thread.sleep(2000);
            }
        } catch (Exception ex) {
            ex.getStackTrace();
            ex.getCause();
        }
    }

    public void selectFromBootstrapDropdown(WebDriver driver, String text, WebElement element) {
        action = new Actions(driver);
        try {
            action.moveToElement(element).click().sendKeys(text).pause(2000)
                    .sendKeys(Keys.DOWN).pause(2000)
                    .sendKeys(Keys.ENTER).build().perform();
        } catch (Exception ex) {
            ex.getStackTrace();
            ex.getCause();
        }
    }

    public void verifyHeroBanner(WebDriver driver, WebElement element) {
        try {
            boolean imagePresent = (boolean) ((JavascriptExecutor) driver).executeScript("return arguments[0].complete && typeof arguments[0].naturalWidth != \"undefined\" && arguments[0].naturalWidth > 0", element);
            if (!imagePresent) {
                Assert.fail("Image not present");
            } else
                Assert.assertTrue(imagePresent, "Image not present");
        } catch (Exception ex) {
            ex.getStackTrace();
            ex.getCause();
        }
    }
}