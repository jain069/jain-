package com.testx.web.api.selenium.restassured.qe.ui.stepdefinitions.bjs_steps;


import com.testx.web.api.selenium.restassured.qe.ui.context.TestContext;
import com.testx.web.api.selenium.restassured.qe.ui.custom_exceptions.InvalidCommonStepSelectionException;
import com.testx.web.api.selenium.restassured.qe.ui.pageobjects.CateringPage;
import com.testx.web.api.selenium.restassured.qe.ui.stepdefinitions.BaseSetup;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.http.HttpResponse;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.asserts.SoftAssert;

import java.time.Duration;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

import static org.testng.AssertJUnit.*;

public class CateringStepDef extends BaseSetup {
    TestContext testContext;
    private CateringPage cateringPage;
    WebDriverWait wait = new WebDriverWait(driver, 30);
    JavascriptExecutor js = (JavascriptExecutor) driver;

    public CateringStepDef(TestContext testContext, CateringPage cateringPage) {
        super(testContext);
        this.testContext = testContext;
        this.cateringPage = cateringPage;
    }
    @Then("^I verify tab title is equal to header title in (.*)$")
    public void verifyTabTitleIsEqualToHeader(String pageClassName, DataTable dataTable) throws InterruptedException {
        List<Map<String, String>> rows = dataTable.asMaps(String.class, String.class);
        WebElement elements = loadWebElement(rows.get(0).get("Header Title"), pageClassName);
        driverManagerUtils.findElementAndHighlight(driver, elements, "blue");
        String tabTitle = rows.get(0).get("Tab Title");
        String headerTitle = elements.getText();
        if (tabTitle.equals(headerTitle)) {
            Assert.assertTrue("Expected Partially Text is : " + tabTitle + " And Actual Text is: "
                    + headerTitle, true);
        } else {
            Assert.fail("Expected was: " + tabTitle + " And Actual is : " + headerTitle);
        }

    }

    @Then("^I verify that all tabs has the price/cal information in (.*)$")
    public void verifyTabPrices(String pageClassName, DataTable dataTable) throws InterruptedException {
        List<Map<String, String>> rows = dataTable.asMaps(String.class, String.class);
        List<WebElement> elements = loadWebElements(rows.get(0).get("Field"), pageClassName);
        for (WebElement ele : elements) {
            driverManagerUtils.findElementAndHighlight(driver, ele, "red");
            String expectedText = rows.get(0).get("Text");
            String actualText = ele.getText();
            if (actualText.contains(expectedText)) {
                Assert.assertTrue("Expected Partially Text is : " + expectedText + " And Actual Text is: "
                        + actualText, true);
            } else {
                Assert.fail("Expected was: " + expectedText + "And Actual text is: " + actualText);
            }
        }
    }

    @Then("^I verify that all included items has the included tag in (.*)$")
    public void verifyIncludedTag(String pageClassName, DataTable dataTable) throws InterruptedException {
        List<Map<String, String>> rows = dataTable.asMaps(String.class, String.class);
        List<WebElement> elements = loadWebElements(rows.get(0).get("Field"), pageClassName);
        for (WebElement ele : elements) {
            driverManagerUtils.findElementAndHighlight(driver, ele, "red");
            String expectedText = rows.get(0).get("Text");
            String actualText = ele.getText();
            if (actualText.contains(expectedText)) {
                Assert.assertTrue("Expected Partially Text is : " + expectedText + " And Actual Text is: "
                        + actualText, true);
            } else {
                Assert.fail("Expected was: " + expectedText + "And Actual text is: " + actualText);
            }
        }
    }

    @Then("I add to order the required Boxed Meals to proceed to CheckOut")
    public void verifyIncludedTag() throws InterruptedException {

        for (int i=1;i<=8;i++) {
            driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
            driver.findElement(By.xpath("//*[contains(@type,'button')]//*[contains(text(),'ADD')]")).click();
            //WebElement firstResult = new WebDriverWait(driver, Duration.ofSeconds(10))
            //        .until(ExpectedConditions.elementToBeClickable
            //                (By.xpath("//*[contains(@type,'button')]//*[contains(text(),'OK')]")));
            WebElement okbtn= driver.findElement(By.xpath("//*[contains(@type,'button')]//*[contains(text(),'OK')]"));
            wait.until(ExpectedConditions.elementToBeClickable(okbtn));
            okbtn.click();
            if (i == 8) {
                Assert.assertTrue("All required boxed meals were added", true);
            }
        }
    }
    @And("I resize the window to {int} x {int} size")
    public void resizeWindow(int w, int h) throws InterruptedException {
        driver.manage().window().setSize(new Dimension(w, h));
    }

    @And("I scroll to the end of the page")
    public void iScrollToTheEndOfThePage() throws InterruptedException {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,document.body.scrollHeight)");
    }

    @Then("^I verify the items image, name and copy description of (.*) in the (.*)$")
    public void verifySandwichPlattersItems(String element, String page) {
        SoftAssert softAssert = new SoftAssert();
        List<WebElement> items = loadWebElements(element, page);
        for (WebElement ele : items) {
            driverManagerUtils.findElementAndHighlight(driver, ele, "red");
            WebElement name = ele.findElement(By.cssSelector("h3"));
            driverManagerUtils.findElementAndHighlight(driver, name, "blue");
            softAssert.assertTrue(name.isDisplayed() && !name.getText().isEmpty());
            WebElement copy = ele.findElement(By.cssSelector("p"));
            driverManagerUtils.findElementAndHighlight(driver, copy, "blue");
            softAssert.assertTrue(copy.isDisplayed() && !copy.getText().isEmpty());
            WebElement image = ele.findElement(By.cssSelector("img"));
            driverManagerUtils.findElementAndHighlight(driver, image, "blue");
            String sourceValue = image.getAttribute("src");
            HttpResponse response = driverManagerUtils.getResponseFromSource(sourceValue);
            softAssert.assertTrue(image.isDisplayed() && response.getStatusLine().getStatusCode() == 200);
        }
        softAssert.assertAll();
    }

    @Then("^I verify that Sandwich List Section is (visible|not visible) in the CateringPage$")
    public void verifyVisibilityOff(String visibility) {
        switch (visibility){
            case "visible":
                try {
                    WebElement section = new WebDriverWait(driver, Duration.ofSeconds(3))
                            .until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("div[id='Sandwich Choices'] > div > div > div > div > div > div")));
                    assertTrue("Section is displayed in the Page!", section.isDisplayed());
                } catch (org.openqa.selenium.TimeoutException ex) {
                    fail("Section is displayed on the Page!");
                }
                break;
            case "not visible":
                try {
                    Boolean section = new WebDriverWait(driver, Duration.ofSeconds(3))
                            .until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector("div[id='Sandwich Choices'] > div > div > div > div > div > div")));
                    assertTrue("Section is displayed in the Page!", section);
                } catch (org.openqa.selenium.TimeoutException ex) {
                    fail("Section is displayed on the Page!");
                }
                break;
            default:
                throw new InvalidCommonStepSelectionException(visibility);
        }
    }

    @And("^I verify the (.*) goes (up|down) completed by 2 in the (.*)$")
    public void verifyByTwo(String element,String go, String page) {
        WebElement steppers = loadWebElement(element,page);
        WebElement number = steppers.findElement(By.cssSelector("span > span"));
        switch(go){
            case "up":
                int countUP = 2;
                WebElement plusButton = steppers.findElement(By.cssSelector("button:nth-child(3)"));
                assertEquals("Number is not a 2: " + number.getText(), 2, Integer.parseInt(number.getText()));
                for(int i = 0; i < 7; i++){
                    driverManagerUtils.clickJSElement(plusButton);
                    countUP+=2;
                    assertTrue("Number is not a multiply of 2 or the number is not the expected: "+number.getText(),
                            Integer.parseInt(number.getText())==countUP && Integer.parseInt(number.getText())%2==0);
                }
                break;
            case "down":
                assertEquals("Number is not a 16: " + number.getText(), 16, Integer.parseInt(number.getText()));
                int countDown = 16;
                WebElement minusButton = steppers.findElement(By.cssSelector("button:nth-child(1)"));
                for(int j = 8; j > 0; j--){
                    assertTrue("Number is not a multiply of 2 or the number is not the expected: "+number.getText(),
                            Integer.parseInt(number.getText())==countDown && Integer.parseInt(number.getText())%2==0);
                    countDown-=2;
                    driverManagerUtils.clickJSElement(minusButton);
                }
                break;
            default:
                throw new InvalidCommonStepSelectionException(go);
        }
    }

    @And("^I click on the (.*) in the list$")
    public void clickFirstItemList(String item) {
        WebElement itemList = loadWebElement(item, "CateringPage");
        driverManagerUtils.findElementAndHighlight(driver,itemList,"Yellow");
        driverManagerUtils.clickJSElement(itemList);
    }

    @Then("^I add the required number of items in the cart using the (.*)$")
    public void addRequiredItems(String element) {
        List<WebElement> stepper = loadWebElements(element,"CateringPage");
        WebElement check = driver.findElement(By.cssSelector("div[id='Sandwich Choices']  div > div > div > p:nth-child(1)"));
        int item = 0;
        int count = 0;
        while(!check.getText().contains("8 of 8")){
            WebElement stepperElement = stepper.get(item).findElement(By.cssSelector("button:nth-child(3)"));
            stepperElement.click();
            count++;
            if(count==2){
                item++;
                count=0;
            }
        }
    }

    @And("I verify the mini summary in the Sandwich Platters Page")
    public void miniSummarySandwichPlatters() throws Exception {
        List<WebElement> items = loadWebElements("miniSummaryList","CateringPage");
        SoftAssert softAssert = new SoftAssert();
        int count = 1;
        for(WebElement item: items){
            driverManagerUtils.scrollToElement(item);
            WebElement img = item.findElement(By.cssSelector("img"));
            driverManagerUtils.findElementAndHighlight(driver,img,"Yellow");
            HttpResponse response = driverManagerUtils.getResponseFromSource(img.getAttribute("src"));
            softAssert.assertTrue(response.getStatusLine().getStatusCode() == 200 && img.isDisplayed(),"Item#: "+count+" ->img");
            WebElement name = item.findElement(By.cssSelector("div:nth-child(2) > p:nth-child(1)"));
            driverManagerUtils.findElementAndHighlight(driver,name,"Blue");
            softAssert.assertTrue(!name.getText().isEmpty() && name.isDisplayed(),"Item#: "+count+" ->name");
            WebElement copy = item.findElement(By.cssSelector("div > div > p+p"));
            driverManagerUtils.findElementAndHighlight(driver,copy,"Red");
            softAssert.assertTrue(!copy.getText().isEmpty() && copy.isDisplayed(),"Item#: "+count+" ->copy");
            try{
                WebElement adds = item.findElement(By.cssSelector("div[class='items '] div:nth-child(2) > div:nth-child(3) > p:nth-child(1)"));
                if(adds.getText().isEmpty()){
                    throw new NoSuchElementException();
                }
                driverManagerUtils.findElementAndHighlight(driver,adds,"Black");
                softAssert.assertTrue(!adds.getText().isEmpty() && adds.isDisplayed(),"Item#: "+count+" ->adds");
            }catch(NoSuchElementException ex){
                System.out.println("Item with no addons");
            }
            WebElement customize = item.findElement(By.cssSelector("button[type='button']"));
            driverManagerUtils.findElementAndHighlight(driver,customize,"Grey");
            softAssert.assertTrue(customize.isEnabled() && !customize.getText().isEmpty(),"Item#: "+count+" ->custo");
            WebElement closeButton = item.findElement(By.cssSelector("button > div"));
            driverManagerUtils.findElementAndHighlight(driver,closeButton,"Orange");
            softAssert.assertTrue(closeButton.isDisplayed(),"Item#: "+count+" ->close");
            count++;
        }
        softAssert.assertAll();
    }

    @And("I verify the Sandwich Platters were added it in the cart")
    public void itemInTheCart() {
        WebElement cart = loadWebElement("cartWithItem", "BJsHomePage");
        assertEquals("Not matching -> "+cart.getAttribute("data-count")+" != 1","1",cart.getAttribute("data-count"));
    }

    @Then("I Cancel my order from Confirmation page")
            public void cancelItem()throws InterruptedException
            {
                WebElement Cancelbtn= driver.findElement(By.xpath("//p[contains(text(),'Cancel Order')]"));
                wait.until(ExpectedConditions.elementToBeClickable(Cancelbtn));
                Cancelbtn.click();
                WebElement Removebtn= driver.findElement(By.xpath("//p[contains(text(),'Remove')]"));
                wait.until(ExpectedConditions.elementToBeClickable(Removebtn));
                Removebtn.click();

            }
    @When("I Select Future date and time in location edit page")
    public void date_and_time()throws InterruptedException {
        WebElement Date= driver.findElement(By.xpath("//div[@aria-hidden='true']"));
        js.executeScript("arguments[0].scrollIntoView(true);", Date);
        wait.until(ExpectedConditions.elementToBeClickable(Date));
        Date.click();
        WebElement SelectDate= driver.findElement(By.xpath("//div[@id='react-select-4-option-3']"));
        SelectDate.click();
    }

}