package com.testx.web.api.selenium.restassured.qe.ui.stepdefinitions.bjs_steps;

import com.testx.web.api.selenium.restassured.qe.common.utils.config.Configuration;
import com.testx.web.api.selenium.restassured.qe.common.utils.config.ConfigurationManager;
import com.testx.web.api.selenium.restassured.qe.ui.context.TestContext;
import com.testx.web.api.selenium.restassured.qe.ui.pageobjects.ProductDetailPage;
import com.testx.web.api.selenium.restassured.qe.ui.stepdefinitions.BaseSetup;
import com.testx.web.api.selenium.restassured.qe.ui.stepdefinitions.prebuilt_steps.PrebuiltDataAssertionSteps;
import io.cucumber.java.en.And;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ProductDetailPageStepDef extends BaseSetup {

    private static final Logger LOGGER = LoggerFactory.getLogger(ProductDetailPageStepDef.class);
    public static Configuration configuration = ConfigurationManager.getConfiguration();
    TestContext testContext;
    private ProductDetailPage productDetailPage;
    public ProductDetailPageStepDef(TestContext context, ProductDetailPage productDetailPage) {
        super(context);
        this.testContext = context;
        this.productDetailPage = productDetailPage;
    }
    @And("^I select label (.*) for category (.*)$")
    public void selectLabelForCategory (String label, String category) {
        ProductDetailPage.returnElement(driver, label, category);
    }
}
