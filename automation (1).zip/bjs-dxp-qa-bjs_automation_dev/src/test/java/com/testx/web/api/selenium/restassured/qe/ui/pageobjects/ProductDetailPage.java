package com.testx.web.api.selenium.restassured.qe.ui.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class ProductDetailPage extends AbstractPageObject{
    static WebDriverWait wait = null;
    @FindBy(xpath = "//button[@data-testid='icon-button' and contains(@aria-label,'back')]")
    public static WebElement buttonBack;

    @FindBy(xpath = "//h1[text()='Bistro Burger']")
    public static WebElement textTitle;

    @FindBy(xpath = "//*[text()='Bistro Burger']")
    public static WebElement bistroBurger;

    @FindBy(xpath = "(//*[contains(text(), 'Bistro Burger')])[1]")
    public static WebElement Product2;

    @FindBy(xpath = "//*[text()='Classic Burger*']")
    public static WebElement classicBurger;

    @FindBy(xpath = "//h1")
    public static WebElement itemTitle;

    @FindBy(xpath = "//p[contains(text(),'Calories')]")
    public static WebElement itemCalories;

    @FindBy(xpath = "//p[contains(text(),'$')]")
    public static WebElement itemPrice;

    @FindBy(xpath = "//section//following::p[2]")
    public static WebElement itemDescription;

    @FindBy(xpath = "//*[starts-with(text(), 'This burger starts off with a toasted parker')]/parent::*/preceding-sibling::div/p")
    public static WebElement textPrice;

    @FindBy(xpath = "//p[text()='SHOW MORE']//preceding::p[contains(text(),'Calories')]")
    public static WebElement textCalorie;

    @FindBy(xpath = "//*[text()='SHOW MORE']")
    public static WebElement textShowMore;

    @FindBy(xpath = "//*[starts-with(text(), 'This burger starts off with a toasted parker')]")
    public static WebElement textBodyCopy;

    @FindBy(xpath = "//*[text()='SHOW LESS']")
    public static WebElement textShowLess;

    @FindBy(xpath = "//section/p/text()")
    public static WebElement textBodyCopyPartial;

    @FindBy(xpath = "//*[starts-with(text(), '2,000 calories a day is used for')]")
    public static WebElement textCalorieDisclaimer;

    @FindBy(xpath ="//*[text()='BEVERAGES']")
    public static WebElement textBeverages;

    @FindBy(xpath ="//*[text()='Made For']/parent::div/following-sibling::div//input")
    public static WebElement textMade;

    @FindBy(xpath ="//*[text()='Special Instructions']/following-sibling::div//input")
    public static WebElement textSpecial;

    @FindBy(xpath ="//button[contains(@aria-label,'Aria label customize')]")
    public static WebElement buttonCustomize;

    @FindBy(xpath ="//*[text()='Add To Order']")
    public static WebElement buttonAddToOrder;

    @FindBy(xpath ="//*[text()='Please complete the mandatory selections']")
    public static WebElement textAlert;

    @FindBy(xpath ="//*[contains(text(),'Fresh Tomato')]//preceding::p[text()='More Options']")
    public static WebElement textMoreOptions;

    @FindBy(xpath="//*[text()='Butter']")
    public static WebElement textButter;

    @FindBy(xpath ="//*[text()='Add Butter']")
    public static WebElement textAdd;

    @FindBy(xpath ="//*[text()='Sourdough']")
    public static WebElement radioButtonSourdough;

    @FindBy(xpath ="//*[text()='American']")
    public static WebElement radioButtonAmerican;

    @FindBy(xpath ="//*[text()='Applewood Smoked Bacon']")
    public static WebElement checkBoxAppleWoodSmokedBacon;

    @FindBy(xpath ="//*[text()='Avocado']")
    public static WebElement checkBoxAvocado;

    @FindBy(xpath ="//*[text()='Save Selection']")
    public static WebElement textSaveSelection;

    @FindBy(xpath ="//div[contains(@class, 'slick-slide slick-active ')]//span[2]/button")
    public static WebElement addAddons;

    @FindBy(xpath ="//div[contains(@class, 'slick-slide slick-active ')]//span[2]/button")
    public static WebElement removeAddons;

    @FindBy(xpath ="//*[text()='Removed from Cart']")
    public static WebElement textRemovedFromCart;

    //Beer Product Page
    @FindBy(css = "section[role='dialog']")
    public static WebElement modalAgeVerification;

    @FindBy(css = "section[role='dialog'] > footer > button:nth-child(1)")
    public static WebElement modalAgeVerificationAccept;

    @FindBy(css = "section[role='dialog'] > footer > button:nth-child(2)")
    public static WebElement modalAgeVerificationDecline;

    @FindBy(css = "section[role='dialog'] > header > button")
    public static WebElement modalAgeVerificationX;

    @FindBy(tagName = "h1")
    public static WebElement beerName;

    //@FindBy(xpath="//*[contains(text(), 'Sides & Extras')]/parent::*/following-sibling::*/button[text()='Burgers']")
    @FindBy(xpath="//button[text()='Burgers']")
    public static WebElement textHandcraftedBurgers;

    @FindBy(xpath="//*[contains(text(), 'BURGERS')]")
    public static WebElement labelHandcraftedBurgers;

    @FindBy(xpath="//*[contains(text(), 'Favorite Pizza - Shareable')]")
    public static WebElement textFavoriteShareablePizza;

    @FindBy(xpath="//h1[contains(text(), 'Favorite Pizza - Shareable')]")
    public static WebElement labelFavoriteShareablePizza;

    @FindBy(xpath="//*[@aria-label='increment-button']")
    public static WebElement buttonIncrement;

    @FindBy(xpath="//*[contains(@id, '5-live-region')]/parent::div")
    public static WebElement partySize;

    @FindBy(xpath="//*[contains(@id, '8-live-region')]/parent::div//hr/following-sibling::div")
    public static WebElement carotForPartySize;

    @FindBy(xpath="//*[text()='START ADDING TO ORDER']")
    public static WebElement StartAddingToOrder;

    @FindBy(xpath = "//*[text()='Time']/following-sibling::div//input")
    public static WebElement Time;

    @FindBy(xpath = "//*[text()='Date']/following-sibling::div//input")
    public static WebElement date;

    @FindBy(xpath = "//*[contains(text(), 'by State')]/following-sibling::div//input")
    public static WebElement byState;

    @FindBy(xpath = "//h1[text()='Diet Pepsi']")
    public static WebElement textDietPepsi;

    @FindBy(xpath = "//*[contains(@id, '1-live-region')]/parent::div")
    public static WebElement dropDownTableFor;

    @FindBy(xpath="//p[text()='Update Order']")
    public static WebElement updateOrder;

    @FindBy(xpath="//*[text()='Side']")
    public static WebElement textSide;

    @FindBy(xpath="//span[contains(text(),'Continue Ordering')]")
    public static WebElement continueOrderButton;


    static String beforeLabel = "//p[contains(text(), '";
    static String afterLabel = "')]/ancestor::button/following-sibling::div//p[text()='";
    static String afterCategory = "']";
    static String close = "')]";

    public static void returnElement(WebDriver driver, String label, String category){
        WebElement ele = null;
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        try {
            Thread.sleep(3000);
            ele = driver.findElement(By.xpath(beforeLabel+category+close));
            wait.until(ExpectedConditions.visibilityOf(ele));
            ele.click();
            Thread.sleep(2000);
            ele = driver.findElement(By.xpath(beforeLabel+category+afterLabel+label+afterCategory));
            ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", ele);
            ((JavascriptExecutor)driver).executeScript("arguments[0].click();", ele);
            Thread.sleep(2000);
            ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", driver.findElement(By.xpath(beforeLabel+category+close)));
            ((JavascriptExecutor)driver).executeScript("arguments[0].click();", driver.findElement(By.xpath(beforeLabel+category+close)));
        }
        catch (Exception ex) {
            ex.getStackTrace();
            ex.getCause();
        }

    }
}