package com.testx.web.api.selenium.restassured.qe.ui.stepdefinitions.bjs_steps;

import com.testx.web.api.selenium.restassured.qe.ui.context.TestContext;
import com.testx.web.api.selenium.restassured.qe.ui.pageobjects.BJsHomePage;
import com.testx.web.api.selenium.restassured.qe.ui.pageobjects.BeerClubLandingPage;
import com.testx.web.api.selenium.restassured.qe.ui.stepdefinitions.BaseSetup;
import io.cucumber.java.en.And;
import org.apache.http.HttpResponse;
import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.asserts.SoftAssert;

import java.time.Duration;
import java.util.List;

public class BeerClubLandingPageStepDef extends BaseSetup {
    TestContext testContext;
    private BeerClubLandingPage beerClubLandingPage;

    public BeerClubLandingPageStepDef(TestContext context, BeerClubLandingPage beerClubLandingPage) {
        super(context);
        this.testContext = context;
        this.beerClubLandingPage = beerClubLandingPage;
    }

    @And("^I verify the cards carousel of the (.*) on the (.*)$")
    public void iVerifyTheCardsOfTheRewardsCarouselOnTheDashboardPage(String element, String webPage) {
        SoftAssert softAssertions = new SoftAssert();
        int count = 0;
        WebElement next = driver.findElement(By.cssSelector("div[class='css-k008qs'] > button[aria-label='Next Page']"));
        List<WebElement> listCards = loadWebElements(element, webPage);
        for (WebElement ele : listCards) {
            WebElement img = ele.findElement(By.cssSelector("div[role='img']"));
            driverManagerUtils.findElementAndHighlight(driver, img, "red");
            String style = img.getAttribute("style");
            if(style.contains("http")){
                String sourceValue = driverManagerUtils.getImageSource(style);
                HttpResponse response = driverManagerUtils.getResponseFromSource(sourceValue);
                softAssertions.assertTrue(ele.isDisplayed() && response.getStatusLine().getStatusCode() == 200);
            }else{
                softAssertions.fail("Image: "+(count+1)+" is not present");
            }
            WebElement name = ele.findElement(By.cssSelector("div[role='img'] p"));
            driverManagerUtils.findElementAndHighlight(driver, name, "blue");
            softAssertions.assertTrue(!name.getText().isEmpty() && name.isDisplayed());
            ele.click();
            WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(5));
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("section[role='dialog'] img")));
            img = driver.findElement(By.cssSelector("section[role='dialog'] img"));
            HttpResponse response = driverManagerUtils.getResponseFromSource(img.getAttribute("src"));
            driverManagerUtils.findElementAndHighlight(driver, img, "blue");
            softAssertions.assertTrue(response.getStatusLine().getStatusCode() == 200 && img.isDisplayed());
            name = driver.findElement(By.cssSelector("section[role='dialog'] div[class='css-0']"));
            driverManagerUtils.findElementAndHighlight(driver, name, "red");
            softAssertions.assertTrue(!name.getText().isEmpty() && name.isDisplayed());
            driver.findElement(By.cssSelector("section[role='dialog'] > header > button")).click();
            count++;
            if (count % 3 == 0 && count < listCards.size()) {
                count = 0;
                next.click();
                driverManagerUtils.sleep(1000);
            }
        }
        softAssertions.assertAll();
    }
}