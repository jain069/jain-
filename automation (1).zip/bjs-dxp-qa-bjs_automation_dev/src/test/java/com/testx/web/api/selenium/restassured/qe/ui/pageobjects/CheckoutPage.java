package com.testx.web.api.selenium.restassured.qe.ui.pageobjects;

import com.testx.web.api.selenium.restassured.qe.ui.webdriver.DriverManagerUtils;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class CheckoutPage extends AbstractPageObject {

    @FindBy(xpath = "//h1[contains(text(), 'Checkout')]")
    public static WebElement headerCheckout;

    @FindBy(xpath = "//*[@data-testid='banner']//*[contains(text(), 'Become a loyalty member to get a')]")
    public static WebElement textDescription;

    @FindBy(xpath = "//*[contains(text(), 'FREE Pizookie ')]")
    public static WebElement textPizookie;

    @FindBy(xpath = "//*[text()='Checkout ']/preceding-sibling::button")
    public static WebElement buttonBack;

    @FindBy(xpath = "//*[text()='JOIN REWARDS']")
    public static WebElement buttonJoinRewards;

    @FindBy(xpath = "//*[text()='LOG IN']")
    public static WebElement buttonLogIn;

    @FindBy(id = "search-input")
    public static WebElement searchInput;

    @FindBy(xpath = "//*[text()='Culver City']/ancestor::div[contains(@class, 'sc-e')]/following-sibling::div//*[text()='ORDER AHEAD']")
    public static WebElement orderAhead;

    @FindBy(xpath = "//*[contains(@class, '-chevron-up')]/preceding-sibling::h1")
    public static WebElement textMenuItems;

    @FindBy(xpath = "//*[contains(@class, 'is-open')]//following-sibling::div//p[text()='Diet Pepsi']")
    public static WebElement textDietPepsi;

    @FindBy(xpath = "//*[contains(@class, 'is-open')]//following-sibling::div//button[@aria-label='decrement-button']")
    public static WebElement buttonDecrement;

    @FindBy(xpath = "//*[contains(@class, 'is-open')]//following-sibling::div//button[@aria-label='increment-button']")
    public static WebElement buttonIncrement;

    @FindBy(xpath = "//*[contains(@class, 'is-open')]//following-sibling::div//p[text()='remove']")
    public static WebElement buttonRemove;

    @FindBy(xpath = "//*[contains(@class, 'is-open')]//following-sibling::div//*[contains(@class, '-edit')]")
    public static WebElement buttonEdit;

    @FindBy(xpath = "//*[text()='Remove']")
    public static WebElement popUpRemove;

    @FindBy(xpath = "//*[text()='cancel']")
    public static WebElement popUpCancel;

    @FindBy(xpath = "//*[contains(text(), 'Are you sure you want to remove')]")
    public static WebElement popUpDescription;

    @FindBy(xpath = "//*[text()='Remove Item']/parent::div/following-sibling::button")
    public static WebElement buttonClose;

    @FindBy(xpath = "//*[contains(text(),'Do you need anything else?')]")
    public static WebElement orderInstructions;

    @FindBy(xpath = "//*[contains(text(),'*Utensils')]")
    public static WebElement orderInstructions1;

    @FindBy(xpath = "//*[@aria-label='Add order instructions (optional)']")
    public static WebElement orderInstructions2;

    @FindBy(xpath = "//span[@class='chakra-text css-13yteit']")
    public static WebElement errorMessage;

    @FindBy(xpath = "//*[text()='Available rewards and offers']")
    public static WebElement avlRewardsOffers;

    @FindBy(xpath = "//*[contains(text(),'SHOW ALL')]")
    public static WebElement showAllBtn;

    @FindBy(xpath = "//*[contains(text(),'SHOW LESS')]")
    public static WebElement showLessBtn;


    @FindBy(xpath = "//*[text()='Dine In']")
    public static WebElement textDineIn;

    @FindBy(xpath = "//*[text()='Edit']")
    public static WebElement buttonEditAtCheckout;

    // rewards
    @FindBy(xpath = "//span[contains(text(),'LOG-IN')]")
    public static WebElement headerLogIn;

    @FindBy(xpath = "(//*[contains(@class,'sc-eCOUaW dDMGTP')])[1]/button")
    public static WebElement buttonAdd;

    @FindBy(xpath = "//p[text()='Unapply']")
    public static WebElement buttonUnapply;

    @FindBy(xpath = "//*[text()='Your Order']")
    public static WebElement yourOrderLabel;

    @FindBy(xpath = "//*[contains(text(),'Take Out, Curbside or Delivery Only')]")
    public static WebElement awardAvailable;

    @FindBy(xpath = "(//*[contains(@aria-label,'Button Icon')])[4]")
    public static WebElement addAward;

    @FindBy(xpath = "(//*[contains(@id,'chakra-modal--body')])//div[7]//*[contains(text(), 'Amount due')]")
    public static WebElement amountDue;

    @FindBy(xpath = "(//*[contains(@id,'chakra-modal--body')])//div[5]//div[1]//div[1]//p[1]")
    public static WebElement subtotal;

    @FindBy(xpath = "(//*[contains(@id,'chakra-modal--body')])//div[5]//div[1]//div[2]//p[1]")
    public static WebElement taxSumm;

    @FindBy(xpath = "//*[contains(text(),'Beer Club Large Pizza Perk')]")
    public static WebElement awardSummary;

    @FindBy(xpath = "(//*[contains(@class,'icon-bjs-close')])")
    public static WebElement xButtonCart;

    @FindBy(xpath = "(//*[contains(@aria-label,'Button Icon')])[4]")
    public static WebElement removeAward;

    @FindBy(xpath = "(//*[contains(@class,'remove-link')])[1]//p[1]")
    public static WebElement removeItem;

    @FindBy(xpath = "//*[text()='Total']")
    public static WebElement total;


    @FindBy(xpath = "//div[@aria-label='Shopping Cart']")
    public static WebElement cart;

    @FindBy(xpath = "//div[@aria-label='Shopping Cart']//span//span")
    public static WebElement clickCart;

    @FindBy(xpath = "//p[text()='Return to Menu']")
    public static WebElement returnMenu;

    @FindBy(xpath = "//button[contains(@aria-label,'Add Sliders*')]")
    public static WebElement addSliders;

    @FindBy(xpath = "//input[@aria-label='first Name']")
    public static WebElement firstName;

    @FindBy(xpath = "//input[@aria-label='last Name']")
    public static WebElement lastname;

    @FindBy(xpath = "//input[@aria-label='Email']")
    public static WebElement emailV;

    @FindBy(xpath = "//input[@aria-label='*Phone']")
    public static WebElement phoneNum;

    @FindBy(xpath = "//p[text()='Checkout']")
    public static WebElement checkoutP;


    @FindBy(xpath = "//p[text()='Edit']")
    public static WebElement cartLocEdit;

    //Checkout guest details
    @FindBy(xpath = "//*[text()='Guest Details']")
    public static WebElement textGuestDetails;

    @FindBy(xpath = "//*[contains(@data-testid, 'first-name')]")
    public static WebElement guestfirstName;

    @FindBy(xpath = "//*[contains(@data-testid, 'last-name')]")
    public static WebElement guestLastName;

    @FindBy(xpath = "//*[contains(@data-testid, 'email')]")
    public static WebElement guestEmail;

    @FindBy(xpath = "//*[contains(@data-testid, 'input-phone')]")
    public static WebElement guestPhone;

    @FindBy(xpath = "//*[contains(@data-testid, 'card-number')]")
    public static WebElement CardNumber;

    @FindBy(xpath = "//*[contains(@data-testid, 'cvv')]")
    public static WebElement CVV;

    @FindBy(xpath = "//*[contains(@data-testid, 'expiration')]")
    public static WebElement Expiration;

    @FindBy(xpath = "//*[contains(@data-testid, 'zip-code')]")
    public static WebElement Zip;

    @FindBy(xpath = "//*[@aria-label='No']")
    public static WebElement buttonUtensils;

    @FindBy(xpath = "(//*[contains(text(), 'Order Summary')])[2]")
    public static WebElement textOrderSummary;

    @FindBy(xpath = "(//*[contains(text(), '*Select Tip Amount')])[2]")
    public static WebElement textSelectTip;

    @FindBy(xpath = "//input[@aria-label='Custom Tip']")
    public static WebElement enterCustomTip;


    @FindBy(xpath = "(//*[contains(text(), 'Menu Items (')])[2]")
    public static WebElement textMenuItem;

    @FindBy(xpath = "(//*[text()='Place Order'])[2]")
    public static WebElement buttonPlaceOrder;

    @FindBy(xpath = "//*[contains(text(), 'Order #')]")
    public static WebElement textOrderNumber;

    @FindBy(xpath = "//*[text()='Thank You,']")
    public static WebElement textThankYou;

    @FindBy(xpath = "//*[contains(text(), 'Your order was submitted')]")
    public static WebElement subTextOrderSubmission;

    @FindBy(xpath = "//*[text()='Cancel Order']")
    public static WebElement textCancelOrder;

    @FindBy(xpath = "((//h1[contains(text(), 'Menu Items (')])[2]/following-sibling::*//p)[5]")
    public static WebElement checkout_Product2;

    @FindBy(xpath = "((//h1[contains(text(), 'Menu Items (')])[2]/following-sibling::*//p)[1]")
    public static WebElement checkout_Product1;

    @FindBy(xpath = "((//h1[contains(text(), 'Menu Items (')])[2]/following-sibling::*//p)[6]")
    public static WebElement priceItem2_atCheckout;

    @FindBy(xpath = "((//h1[contains(text(), 'Menu Items (')])[2]/following-sibling::*//p)[2]")
    public static WebElement priceItem1_atCheckout;

    @FindBy(xpath = "(//*[text()='Tax'])[2]/following-sibling::*")
    public static WebElement TaxAmountAtCheckout;

    @FindBy(xpath = "(//*[text()='Amount Due'])[2]/parent::*/following-sibling::*")
    public static WebElement totalAmount;

    @FindBy(xpath = "(//*[@aria-label='other'])[2]")
    public static WebElement selectTipOther;

    @FindBy(xpath = "//*[contains(@type, 'button')]//*[contains(text(),'JOIN')]")
    public static WebElement joinFromCart;
    
    @FindBy(xpath = "//*[contains(text(), 'Test Location')]")
    public static WebElement testLocation;

    @FindBy(xpath = "//*[text()='Pay At Restaurant']/ancestor::span/preceding-sibling::span")
    public static WebElement payAtRestaurant;

    @FindBy(xpath = "//*[contains(text(), 'RETURN TO MENU')]")
    public static WebElement returnToMenu;

    @FindBy(xpath = "//*[contains(@data-testid,'alert')]//div[1]//div[1]")
    public static WebElement alertCart;

    public String fetchProduct1_AtCheckout(DriverManagerUtils driverManagerUtils, WebDriver driver) {
        driverManagerUtils.fluentWaitForElement(driver, checkout_Product1);
        return checkout_Product1.getText();
    }

    public String fetchProduct2_AtCheckout(WebDriver driver) {
        return checkout_Product2.getText();
    }
    public String fetchFirstItemPriceFromCheckout(DriverManagerUtils driverManagerUtils, WebDriver driver) {
        driverManagerUtils.fluentWaitForElement(driver, priceItem1_atCheckout);
        return priceItem1_atCheckout.getText();
    }

    public String fetchSecondItemPriceFromCheckout(DriverManagerUtils driverManagerUtils, WebDriver driver) {
        driverManagerUtils.fluentWaitForElement(driver, priceItem2_atCheckout);
        return priceItem2_atCheckout.getText();
    }

    public String fetchTaxFromCheckout(WebDriver driver) {
        return TaxAmountAtCheckout.getText();
    }

    public String fetchTotalAmountFromCheckout(WebDriver driver) {
        return totalAmount.getText();
    }

    public void validateTotalAmountBetweenCartAndCheckout(String priceOfItem1_atCart, String priceOfItem2_atCart
            , String taxAmount, String totalAmount) {
        try {
            String priceOfItem1 = priceOfItem1_atCart.substring(1);
            double item1 = Double.parseDouble(priceOfItem1);

            String priceOfItem2 = priceOfItem2_atCart.substring(1);
            double item2 = Double.parseDouble(priceOfItem2);

            String taxAtCheckout = taxAmount.substring(1);
            double tax = Double.parseDouble(taxAtCheckout);

            String subTotal = totalAmount.substring(1);
            double amountDue = Double.parseDouble(subTotal);
            double actualAmount = item1 + item2 + tax;
            if (Math.round(amountDue) == Math.round(actualAmount)) {
                Assert.assertTrue(true);
            }
        } catch (Exception ex) {
            Assert.fail("Expected amount: " + amountDue + " doesn't match with actual amount");
            ex.getStackTrace();
            ex.getCause();
        }

    }

}
