package com.testx.web.api.selenium.restassured.qe.ui.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class FamilyMealDealPage extends AbstractPageObject {

    @FindBy(xpath = "//h1[text()='Family Meal Deals']")
    public static WebElement mealDealCategory;

    @FindBy(xpath = "//p[contains(text(),'Save up to 15% with our meal deals.')]")
    public static WebElement mealDealDescription;

    @FindBy(xpath = "//*[contains(text(),'10 items')]")
    public static WebElement mealDealItems;

    @FindBy(xpath = "//p[normalize-space()='Wings Feast']")
    public static WebElement wingsFeast;

    @FindBy(xpath = "//h3[normalize-space()='Boneless Wings']")
    public static WebElement bonelessWings;

    @FindBy(xpath = "//h3[text()=\"Large BJ's Favorite Pizza\"]")
    public static WebElement favoritePizza;

    @FindBy(xpath = "//h3[normalize-space()='House Salad']")
    public static WebElement caesarSalad;

    @FindBy(xpath = "//*[text()=\"BJ's Peppered BBQ\"]")
    public static WebElement radioButtonBbq;

    @FindBy(xpath ="(//*[text()='Cherry Chipotle Glaze'])[2]")
    public static WebElement radioButtonCherry;

    @FindBy(xpath = "//p[text()='Pick 1 Pizza']")
    public static WebElement pizzaChoice;

    @FindBy(xpath ="//span[text()=\"ADD TO ORDER\"]")
    public static WebElement buttonAddToOrder;

    @FindBy(xpath = "//*[text()='Payment Method']")
    public static WebElement paymentMethod;

    @FindBy(xpath = "//*[text()='Change Location']")
    public static WebElement changeLocation;

}
