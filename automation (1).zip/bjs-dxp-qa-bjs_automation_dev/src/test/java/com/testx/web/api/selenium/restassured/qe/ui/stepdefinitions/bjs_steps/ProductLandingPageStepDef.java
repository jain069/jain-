package com.testx.web.api.selenium.restassured.qe.ui.stepdefinitions.bjs_steps;

import com.testx.web.api.selenium.restassured.qe.common.utils.config.Configuration;
import com.testx.web.api.selenium.restassured.qe.common.utils.config.ConfigurationManager;
import com.testx.web.api.selenium.restassured.qe.ui.context.Context;
import com.testx.web.api.selenium.restassured.qe.ui.context.TestContext;
import com.testx.web.api.selenium.restassured.qe.ui.pageobjects.BJsHomePage;
import com.testx.web.api.selenium.restassured.qe.ui.pageobjects.ProductLandingPage;
import com.testx.web.api.selenium.restassured.qe.ui.stepdefinitions.BaseSetup;
import com.testx.web.api.selenium.restassured.qe.ui.stepdefinitions.prebuilt_steps.PrebuiltDataAssertionSteps;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.Map;

public class ProductLandingPageStepDef extends BaseSetup {

    private static final Logger LOGGER = LoggerFactory.getLogger(ProductLandingPageStepDef.class);
    public static Configuration configuration = ConfigurationManager.getConfiguration();
    TestContext testContext;
    private ProductLandingPage productLandingPage;

    public ProductLandingPageStepDef(TestContext context, ProductLandingPage productLandingPage) {
        super(context);
        this.testContext = context;
        this.productLandingPage = productLandingPage;
    }

    @Then("^I verify CheckBoxes section has following CheckBoxes fields on (.*)$")
    public void verifyCheckBoxesField(String pageClassName, DataTable dataTable) {
        List<Map<String, String>> rows = dataTable.asMaps(String.class, String.class);
        for (Map<String, String> column : rows) {
            List<WebElement> Elements = loadWebElements(column.get("Field"), pageClassName);
            String numCheck = column.get("Value");
            int expectedCheckBoxes = Integer.parseInt(numCheck);
            int checkBoxesOnFilterWindow = productLandingPage.numberOfFields(driver, Elements);

            if (expectedCheckBoxes == checkBoxesOnFilterWindow) {
                Assert.assertTrue("Expected checkBoxes are : " + expectedCheckBoxes + " And Actual are "
                        + checkBoxesOnFilterWindow, true);
            } else {
                Assert.fail("Expected checkBoxes are : " + expectedCheckBoxes + " And Actual are "
                        + checkBoxesOnFilterWindow);
            }
        }
    }

    @Then("^I verify Results section has following Results fields for Search/Filter on (.*)$")
    public void verifyResultsList(String pageClassName, DataTable dataTable) {
        List<Map<String, String>> rows = dataTable.asMaps(String.class, String.class);
        for (Map<String, String> column : rows) {
            List<WebElement> Elements = loadWebElements(column.get("Field"), pageClassName);
            String numResults = column.get("Value");
            int expectedResults = Integer.parseInt(numResults);
            int actualResults = productLandingPage.numberOfFields(driver, Elements);

            if (expectedResults == actualResults) {
                Assert.assertTrue("Expected Results are : " + expectedResults + " And Actual are "
                        + actualResults, true);
            } else {
                Assert.fail("Expected Results are : " + expectedResults + " And Actual are "
                        + actualResults);
            }
        }
    }

    @Then("^I verify Results section has the following text in Items on (.*)$")
    public void verifyResultsListSearch(String pageClassName, DataTable dataTable) {
        List<Map<String, String>> rows = dataTable.asMaps(String.class, String.class);
        List<WebElement> elements = loadWebElements(rows.get(0).get("Field"), pageClassName);
        for (WebElement ele : elements) {
            String resultName = rows.get(0).get("Text");
            String resultText = ele.getText();
            if (resultText.contains(resultName)) {
                Assert.assertTrue("Expected Partially Text is : " + resultName + " And Actual Text is "
                        + resultText, true);
            } else {
                Assert.fail("Expected Results are : " + resultName + " And Actual are "
                        + resultText);
            }
        }
    }

    @When("I click Outside the filter modal Window")
    public void iClickOutsideTheFilterModalWindow() {
        Actions action = new Actions(driver);
        action.moveByOffset(0, 0).click().build().perform();
    }

    @And("^I validate Product name and price on Order Cart$")
    public void fetchProductDetails() {
        String product1 = productLandingPage.fetchFirstItemNameFromCart(driverManagerUtils, driver);
        String product2 = productLandingPage.fetchSecondItemNameFromCart(driverManagerUtils, driver);

        try {
            String price_product1 = productLandingPage.fetchFirstItemPriceFromCart(driverManagerUtils, driver);
            String price_product2 = productLandingPage.fetchSecondItemPriceFromCart(driverManagerUtils, driver);
            testContext.scenarioContext.setContext(Context.PRODUCT_NAME1, product1);
            testContext.scenarioContext.setContext(Context.PRODUCT_NAME2, product2);
            testContext.scenarioContext.setContext(Context.Price_PizzaMini, price_product1);
            testContext.scenarioContext.setContext(Context.Price_BistroBurger, price_product2);
        } catch (Exception ex) {
            ex.getStackTrace();
            ex.getCause();
        }
    }

    @And("^I verify Product$")
    public void fetchProduct() {
        String product = productLandingPage.fetchFirstItemNameFromCart(driverManagerUtils, driver);
        try {
            testContext.scenarioContext.setContext(Context.Product, product);
        } catch (Exception ex) {
            ex.getStackTrace();
            ex.getCause();
        }
    }

    @And("^I verify Price$")
    public void fetchPrice() {
        String price = productLandingPage.fetchFirstItemPriceFromCart(driverManagerUtils, driver);
        try {
            testContext.scenarioContext.setContext(Context.Price, price);
        } catch (Exception ex) {
            ex.getStackTrace();
            ex.getCause();
        }
    }
}
