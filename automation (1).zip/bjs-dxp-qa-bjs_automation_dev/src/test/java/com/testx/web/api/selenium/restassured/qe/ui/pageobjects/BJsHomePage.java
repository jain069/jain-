package com.testx.web.api.selenium.restassured.qe.ui.pageobjects;

import com.testx.web.api.selenium.restassured.qe.ui.context.TestContext;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

import java.util.List;

public class BJsHomePage extends AbstractPageObject {
    /*
     * protected BJsHomePage(TestContext testContext) {
     * super(testContext);
     * }
     */

    // @FindBy(xpath = "//h2//descendant-or-self::*[contains(text(), 'FROM THE
    // ORDINARY')]")
    private String beforePath = "//*[text()='", afterPath = "']/ancestor::div[contains(@class, 'active') and @tabindex='0']";

    @FindBy(xpath = "//h2[1]//child::span[1]")
    public static WebElement textHeroTitle;

    @FindBy(xpath = "//*[text()='REWARDS PLUS']")
    public static WebElement textRewardsHeroTitle;

    @FindBy(xpath = "//h2[1]//following::p[1]")
    public static WebElement textHeroSubTitle;

    @FindBy(xpath = "//p[text()='100 Points = $10 Reward']")
    public static WebElement textRewardsSubTitle;

    @FindBy(xpath = "//h2[1]//following::span[3]")
    public static WebElement buttonHeroCTA;

    @FindBy(xpath = "//*[text()='Beers']")
    public static WebElement beersCTA;

    @FindBy(xpath = "//*[text()='Beer Club']")
    public static WebElement beersClubCTA;

    @FindBy(xpath = "//*[text()='Rewards']")
    public static WebElement buttonRewardsCTA;

    @FindBy(xpath = "//h2[1]//following::p[2]")
    public static WebElement textHeroDisclaimer;

    @FindBy(xpath = "//*[text()='Rewards']/ancestor::div[contains(@class, 'css-1')]/following-sibling::div//p")
    public static WebElement textRewardsHeroDisclaimer;

    @FindBy(xpath = "//*[text()='DAILY BREWHOUSE SPECIALS']")
    public static WebElement textSpecials;

    @FindBy(xpath = "//h1[contains(text(), 'Rewards Plus')]")
    public static WebElement textRewardPlus;

    @FindBy(xpath = "//a[@title='BJs Restaurant and Brewhouse. Go to homepage']")
    public static WebElement logoBjs;

    @FindBy(xpath = "//div[@tabindex='0' and contains(@class, 'active')]")
    public static WebElement carousal_card_1;

    @FindBy(xpath = "//*[text()='Rewards']/ancestor::div[contains(@class, 'lazy')]")
    public static WebElement carousal_card_3;

    @FindBy(xpath = "//div[@data-testid='carousel']//child::div[@data-index='0']")
    public static WebElement textCard_1;

    @FindBy(xpath = "//div[@data-testid='carousel']//child::div[@data-index='1']")
    public static WebElement textCard_2;

    @FindBy(xpath = "//div[@data-testid='carousel']//child::div[@data-index='2']")
    public static WebElement textCard_3;

    @FindBy(xpath = "//div[@data-testid='carousel']//child::div[@data-index='3']")
    public static WebElement textCard_4;

    @FindBy(xpath = "//div[@data-testid='carousel']/descendant-or-self::div[contains(@class, 'hero-slider')]//div[@tabindex='-1' and contains(@class, 'slick-slide')]")
    public static List<WebElement> carousalCards;

    @FindBy(xpath = "//*[contains(@class, '__tab-panels')]")
    public static WebElement teaserSection;

    @FindBy(xpath = "//*[text()='Fabulous']")
    public static WebElement textTeaserHeading;

    @FindBy(xpath = "//*[contains(@id, ':--tab-')]")
    public static List<WebElement> teaserTabs;

    @FindBy(xpath = "//button[@data-index='0']")
    public static WebElement buttonTeaserTab1;

    @FindBy(xpath = "//button[@data-index='1']")
    public static WebElement buttonTeaserTab2;

    @FindBy(xpath = "//h2//following::div[@tabindex='0']//h3[1]")
    public static WebElement textTabTitle;

    @FindBy(xpath = "//h2//following::div[@tabindex='0']//h3[1]//following::p[1]")
    public static WebElement textTabDesc;

    @FindBy(xpath = "//h2//following::div[@tabindex='0']//h3[1]//following::span[3]")
    public static WebElement buttonCTA;

    @FindBy(xpath = "(//div[@data-index='2'])[2]")
    public static WebElement teaserCard1;

    @FindBy(xpath = "(//div[@data-index='3'])[2]")
    public static WebElement teaserCard2;

    @FindBy(xpath = "(//div[@data-index='4'])[1]")
    public static WebElement teaserCard3;

    @FindBy(xpath = "//*[contains(@id, ':--tabpanel-1')]//div[1]/button")
    public static WebElement buttonArrowLeft;

    @FindBy(xpath = "//*[contains(@id, ':--tabpanel-1')]//div[3]/button")
    public static WebElement buttonArrowRight;

    @FindBy(xpath = "//*[contains(@id, ':--tabpanel-1')]//p[contains(text(), '1 / ')]")
    public static WebElement pagination;

    @FindBy(xpath = "//p[text()='Craft your own adventure or search and filter our menu']")
    public static WebElement textMenuWizard;

    @FindBy(xpath = "//*[text()='BARBEQUE CHICKEN CHOPPED SALAD']")
    public static WebElement teaser_cardTitle;

    @FindBy(xpath = "//*[text()='Healthy lunch option']")
    public static WebElement teaser_cardSubText;

    @FindBy(xpath = "//div[@data-testid='signup-container']//child::p[1]")
    public static WebElement rewardTitleText;

    @FindBy(xpath = "//div[@data-testid='signup-container']//child::p[2]")
    public static WebElement rewardDescriptionText;

    @FindBy(xpath = "//input[contains(@data-testid, 'text-input')]")
    public static WebElement emailTextbox;

    @FindBy(xpath = "//button[@type='submit']")
    public static WebElement signUpButton;

    @FindBy(xpath = "//a[contains(text(),'CONTACT')]")
    public static WebElement contactUSLink;

    @FindBy(xpath = "//a[text()='CAREERS']")
    public static WebElement careersLink;

    @FindBy(xpath = "//a[text()='INVESTORS']")
    public static WebElement investorsLink;

    @FindBy(xpath = "//a[text()='ABOUT']")
    public static WebElement aboutLink;

    @FindBy(xpath = "//a[contains(@href,'facebook')]")
    public static WebElement facebookIcon;

    @FindBy(xpath = "//a[contains(@href,'instagram')]")
    public static WebElement instagramIcon;

    @FindBy(xpath = "//a[contains(@href,'twitter')]")
    public static WebElement twitterIcon;

    @FindBy(xpath = "//a[contains(@href,'youtube')]")
    public static WebElement youtubeIcon;

    @FindBy(xpath = "//a[contains(@href,'apps.apple.com')]")
    public static WebElement appStoreIcon;

    @FindBy(xpath = "//a[contains(@href,'play.google.com')]")
    public static WebElement playStoreIcon;

    @FindBy(xpath = "//a[text()='Do Not Sell My Info']")
    public static WebElement doNotSellMyInfoLink;

    @FindBy(xpath = "//a[text()='Your CA Privacy Rights']")
    public static WebElement yourCAPrivacyRightsLink;

    @FindBy(xpath = "//a[text()='Awards ']")
    public static WebElement awardsLink;

    @FindBy(xpath = "//a[text()='Terms of Use']")
    public static WebElement termsOfUseLink;

    @FindBy(xpath = "//a[text()='Privacy Policy']")
    public static WebElement privacyPolicyLink;

    @FindBy(xpath = "//a[contains(text(),'Accessibility')]")
    public static WebElement accessibilityStatementLink;

    @FindBy(xpath = "//a[text()='Sitemap']")
    public static WebElement sitemapLink;

    @FindBy(xpath = "//p[contains(text(),'2022')]")
    public static WebElement footerBottomText;

    @FindBy(xpath = "//*[@aria-label='content area 1']//following::h2")
    public static WebElement contentHeading1;

    @FindBy(css = "div[aria-label='beer background'] > h2")
    public static WebElement contentHeading2;

    @FindBy(css = "div[aria-label='content area 1']")
    public static WebElement contentImage1;

    @FindBy(css = "div[aria-label='beer background']")
    public static WebElement contentImage2;

    @FindBy(xpath = "//*[@aria-label='content area 1']//following::h3")
    public static WebElement contentSubHeading1;

    @FindBy(xpath = "(//div[contains(@class,'contentarea-body')])[2]//h3")
    public static WebElement contentSubHeading2;

    @FindBy(xpath = "//*[@aria-label='content area 1']//following::p[1]")
    public static WebElement contentDescription1;

    @FindBy(xpath = "(//div[contains(@class,'contentarea-body')])[2]//p")
    public static WebElement contentDescription2;

    @FindBy(xpath = "//*[@aria-label='content area 1']//following::a[1]")
    public static WebElement contentCTAButton1;

    @FindBy(xpath = "//*[@aria-label='content area 1']//following::a[2]")
    public static WebElement contentCTAButton2;

    @FindBy(xpath = "//*[@aria-label='content area 1']//following::a[3]")
    public static WebElement contentCTAButton3;

    @FindBy(className = "css-f0ap4o")
    public static WebElement contentSection1;

    @FindBy(className = "css-1kj6sl4")
    public static WebElement contentSection2;

    @FindBy(xpath = "(//div[contains(@class,'contentarea-body')])[1]//img")
    public static List<WebElement> collageImagesFirstSection;

    @FindBy(xpath = "(//div[contains(@class,'contentarea-body')])[2]//img")
    public static List<WebElement> collageImagesSecondSection;

    @FindBy(xpath = "(//section[contains(@class,'sc-gGnURB isFbgW')])[1]//img")
    public static List<WebElement> collageImagesFirstSectionMobile;

    @FindBy(xpath = "(//div[contains(@class,'css-qrllub')])[4]")
    public static WebElement beerCarouselSection;

    @FindBy(css = ".css-qrllub > div > h3")
    public static WebElement beerCarouselTitle;

    @FindBy(css = ".css-qrllub > section > p")
    public static WebElement beerCarouselSubTitle;
    @FindBy(css = ".css-qrllub > div > div > div[class='css-gmuwbf']")
    public static WebElement beerCarouselPagination;

    @FindBy(xpath = "(//div[@role='navigation'])[8]//following::span[2]")
    public static WebElement beerCarouselPaginationNext;

    @FindBy(xpath = "(//div[@role='navigation'])[8]//button[1]/span[1]")
    public static WebElement beerCarouselPaginationBack;

    @FindBy(xpath = "(//div[contains(@class,'css-qrllub')])[4]//div[contains(@class,'slick-track')]/div")
    public static List<WebElement> beerCarouselListCards;

    @FindBy(xpath = "(//div[contains(@class,'css-qrllub')])[2]//div[contains(@class,'slick-track')]/div")
    public static List<WebElement> beerCarouselListCardsMobile;

    @FindBy(xpath = "(//div[contains(@class,'css-qrllub')])[4]//div[contains(@role,'img')]")
    public static List<WebElement> beerCarouselListCardsImages;

    @FindBy(xpath = "(//div[contains(@class,'aem-GridColumn')])[11]//div[contains(@role,'img')]/div/div/p[1]")
    public static List<WebElement> beerCarouselListCardsTitle;

    @FindBy(xpath = "(//div[contains(@class,'aem-GridColumn')])[11]//div[contains(@role,'img')]/div/div/p[2]")
    public static List<WebElement> beerCarouselListCardsDescription;

    @FindBy(xpath = "(//div[@data-testid='carousel'])[7]//div[@data-index='0']")
    public static WebElement firstBeerCard;

    @FindBy(xpath = "(//p[@id='release-results-page'])[7]")
    public static WebElement paginationNumbers;

    @FindBy(xpath = "//*[text()='MENU']")
    public static WebElement homePageMenu;

    @FindBy(xpath = "//a[@href='/menu/beverages']")
    public static WebElement menuBeverages;

    @FindBy(xpath = "//*[contains(text(), 'Appetizer')]")
    public static WebElement menuAppetizers;

    @FindBy(xpath = "//*[text()='MENU']//following::img[1]//following::div[1]")
    public static WebElement firstItemOnMenu;

    @FindBy(xpath = "//*[contains(text(), 'Restaurant & Brewhouse - Root Beer, Tea & Sodas')]")
    public static WebElement menuBrewhouse;

    @FindBy(xpath = "//*[contains(text(),'LOG-IN')]")
    public static WebElement loginButton;

    @FindBy(xpath = "//*[text()='Hi, Luis!']")
    public static WebElement loggedInName;

    @FindBy(xpath = "//*[@class='rewards']")
    public static WebElement rewardsHeader;

    @FindBy(xpath = "//*[@href='/account/dashboard']/descendant::span[3]")
    public static WebElement rewardsPoints;

    @FindBy(xpath = "//*[@href='/account/dashboard']/descendant::span[9]")
    public static WebElement rewardsAvailable;

    @FindBy(css = ".user-rewards-location > div:nth-child(2)")
    public static WebElement time_location_EditHeader;

    @FindBy(xpath = "//*[@class='delivery-and-time']/descendant::span[1]")
    public static WebElement deliveryAndTimeHeader;

    @FindBy(xpath = "//*[text()='Find My Location']")
    public static WebElement findLocationLinkHeader;

    @FindBy(xpath = "//span[contains(text(),'MENU')]")
    public static WebElement menuButton;

    @FindBy(xpath = "//a[contains(text(),'VIEW FULL MENU')]")
    public static WebElement viewFullMenu;

    @FindBy(css = "a[class*=logo]")
    public static WebElement logoBjsMenu;

    @FindBy(xpath = "//p[text()='Entrees']")
    public static WebElement entreeSalads;

    @FindBy(xpath = "//*[contains(@class, 'icon-bjs-search')]")
    public static WebElement globalSearchMagnifier;

    @FindBy(xpath = "//a[@href=\"/account/dashboard\"]/span")
    public static WebElement accountButton;

    @FindBy(xpath = "//p[text()='Takeout']")
    public static WebElement takeoutOption;

    @FindBy(xpath = "//*[contains(@data-testid, 'icon-button')][1]")
    public static WebElement backArrowLoc;

    @FindBy(xpath = "//*[text()='Find My Location']")
    public static WebElement findMyLocation;

    public int countNumberOfCards(WebDriver driver, List<WebElement> elementList) {
        int count = 0;
        for (WebElement ele : elementList) {
            count++;
        }
        System.out.println("Total count is: " + count);
        return count;
    }

    @FindBy(xpath = "//p[contains(text(),'MENU')]")
    public static WebElement MenuButton;

    @FindBy(xpath = "//a[contains(text(),'CATERING')]")
    public static WebElement CateringButton;

    @FindBy(xpath = "//a[contains(text(),'OUR BEER')]")
    public static WebElement OurBeerButton;

    @FindBy(xpath = "//a[contains(text(),'DEALS & MORE')]")
    public static WebElement DealsAndMoreButton;

    @FindBy(xpath = "//a[contains(text(),'GIFT CARDS')]")
    public static WebElement GiftCards;

    @FindBy(xpath = "//span[contains(text(),'ORDER NOW')]")
    public static WebElement OrderNowButton;

    @FindBy(xpath = "//*[contains(text(),'VIEW FULL MENU')]")
    public static WebElement ViewFullMenuButton;

    @FindBy(xpath = "//p[contains(text(),'LOG-IN')]")
    public static WebElement LOGIN_SIGNUP;

    @FindBy(xpath = "//p[contains(text(),'Get a Free Pizookie®')]")
    public static WebElement Pizookie_Message;

    @FindBy(xpath = "//span[contains(text(),'Find My Location')]")
    public static WebElement FindMyLocation;

    @FindBy(xpath = "(//span[@class='icon-bjs-search undefined'])[1]")
    public static WebElement Search;

    @FindBy(xpath = "//p[contains(text(),'BJ’s Premier Reward PLUS')]")
    public static WebElement Login_Page;

    @FindBy(xpath = "//span[@class='path9']")
    public static WebElement Logo;

    @FindBy(xpath = "//h2[contains(text(),'Reward PLUS')]")
    public static WebElement RewardPLUS;

    @FindBy(xpath = "//*[@class='icon-bjs-hamburger undefined']")
    public static WebElement mobileHamburgerBt;

    @FindBy(xpath = "//*[text()='MENU']")
    public static WebElement mobileMenuBt;

    @FindBy(xpath = "//*[text()='Beverages']")
    public static WebElement mobileMenuBeveragesBt;

    @FindBy(xpath = "//*[contains(text(),'Gluten-Sensitive Options')]/../button")
    public static WebElement mobileGlutenSensitiveBt;

    @FindBy(xpath = "//*[text()='Pasta Favorites']")
    public static WebElement pastaFavorites;

    @FindBy(xpath = "(//*[contains(text(), 'Hi,')])[1]")
    public static WebElement welcomeMessage;

    @FindBy(xpath = "//span[contains(text(),'Location')]")
    public static WebElement location;

    @FindBy(css = "a[href='/beerclub']")
    public static WebElement beerClubButton;

    @FindBy(xpath = "//*[text()='Edit']")
    public static WebElement locEdit;

    @FindBy(xpath = "//*[@class='icon-bjs-bag stack-2']")
    public static WebElement cartBtn;

    @FindBy(xpath = "//*[@data-testid='apartment']")
    public static WebElement addAptSuite;

    @FindBy(xpath = "//p[text()='Remove']")
    public static WebElement removeLink;

    @FindBy(xpath = "//input[@data-testid='text-input']")
    public static WebElement deliveringToInput;

    @FindBy(xpath = "//p[text()='START ADDING TO ORDER']")
    public static WebElement startAddingOrder;

    @FindBy(xpath = "//p[text()='Deliverying to']")
    public static WebElement Deliverying;

    @FindBy(xpath = "//li[contains(text(), ' Park Way, Cupertino, CA, USA')]")
    public static WebElement addressSuggestion;

    @FindBy(xpath = "//p[text()='Change Location']")
    public static WebElement changeLocation;

    @FindBy(xpath = "//p[text()='ORDER AHEAD']")
    public static WebElement orderAhead;

    @FindBy(xpath = "//p[text()='Yes, Change Location']")
    public static WebElement ChangeLocationText;

    @FindBy(xpath = "//p[contains(text(), 'Keep This Location')]")
    public static WebElement keepLocationText;

    @FindBy(xpath = "//p[text()='Takeout']")
    public static WebElement takeOut;

    @FindBy(xpath = "//*[text()='LOG-IN']/ancestor::span/following-sibling::span[2]//*[contains(text(), 'SIGN UP')]")
    public static WebElement linkSignUp;

    @FindBy(xpath = "//input[@data-testid='search-input']")
    public static WebElement deliveryAddressInput;

    @FindBy(xpath = "//p[text()='Delivery']")
    public static WebElement deliveryLbl;

    @FindBy(xpath = "//p[text()='ORDER DELIVERY']")
    public static WebElement orderDelivery;

    @FindBy(xpath = "//p[text()='Order Details']")
    public static WebElement orderDetailsLbl;

    @FindBy(xpath = "//p[normalize-space()='Est. wait time: 183 mins']")
    public static WebElement wait;

    @FindBy(xpath = "(//button[@data-testid='icon-button'])[1]")
    public static WebElement leftArrow;

    @FindBy(xpath = "(//button[@data-testid='icon-button'])[2]")
    public static WebElement close;

    @FindBy(xpath = "(//h2[text()='Merge Accounts']/../..//div[2]//div//div)[1]")
    public static WebElement emailVa;

    @FindBy(xpath = "//span[text()='Dine In']")
    public static WebElement dineIn;

    @FindBy(xpath = " //p[text()='ORDER TAKEOUT']")
    public static WebElement orderTakeout;

    @FindBy(xpath = " //p[text()='Delivery']")
    public static WebElement deliveryBtn;

    @FindBy(css = "a[aria-label='Global Search']")
    public static WebElement globalSearch;

    @FindBy(css = "input[data-testid='search-input']")
    public static WebElement searchInput;

    @FindBy(css = "button[data-testid='search-btn']")
    public static WebElement searchButton;

    @FindBy(css = "a[href='/menu-item/classic-burger-4'")
    public static WebElement burgerItem;

    @FindBy(css = "a[href='/rewards']")
    public static WebElement signUpHeader;

    @FindBy(xpath = "//a[text()='MEAL DEALS']")
    public static WebElement mealDealButton;

//ViewCartItems

    @FindBy(xpath = "//span[@class='stack-1']")
    public static WebElement cartIcon;

    @FindBy(xpath = "//h1[contains(text(),'Your Order')]")
    public static WebElement Your_Order;

    @FindBy(xpath = "//p[@class='chakra-text css-1otm4hn']")
    public static WebElement No_of_Items;

    @FindBy(xpath = "//p[contains(text(),'Add More Items')]")
    public static WebElement AddMoreItems;

    @FindBy(xpath = "//p[@class='chakra-text reward-text-container css-0']")
    public static WebElement RewardPoints;

    @FindBy(xpath = "//button[@class='chakra-button sc-iqcoie daITTQ css-jb5tx4']")
    public static WebElement Checkout_Button;

    @FindBy(css = "div[role='button'] > span > span")
    public static WebElement cartWithItem;


    public void verifyZoomedImage(WebDriver driver, String cardTitle) {
        try {
            WebElement element = driver.findElement(By.xpath(beforePath + cardTitle + afterPath));
            if (element.isEnabled()) {
                Assert.assertTrue(true);
            } else
                Assert.fail("First Carousal card with Card Title: " + cardTitle + " is not auto selected on the page load");
        } catch (Exception ex) {
            ex.printStackTrace();
            ex.getCause();
        }
    }

    public void verifyMaximumLength(WebDriver driver, WebElement ele, Integer maxLength) {
        try {
            String title = ele.getText();
            char[] chars = title.toCharArray();
            if (chars.length <= maxLength) {
                Assert.assertTrue(true, "Actual text: " + title + " -> length is: " + chars.length
                        + " ,which is greater than expected maximum length: " + maxLength);
            } else
                Assert.fail("Actual text: " + title + " -> length is: " + chars.length
                        + " ,which is greater than expected maximum length: " + maxLength);
        } catch (NumberFormatException ex) {
            ex.getStackTrace();
            ex.getCause();
        }
    }

}