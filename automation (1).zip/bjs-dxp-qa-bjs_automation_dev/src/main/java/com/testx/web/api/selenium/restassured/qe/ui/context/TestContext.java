package com.testx.web.api.selenium.restassured.qe.ui.context;

import com.testx.web.api.selenium.restassured.qe.ui.webdriver.DriverManager;

public class TestContext {

    DriverManager driverManager;
    public ScenarioContext scenarioContext;

    public TestContext() {
        driverManager = new DriverManager();
        scenarioContext = new ScenarioContext();
    }

    public DriverManager getDriverManager() {
        return driverManager;
    }
}
