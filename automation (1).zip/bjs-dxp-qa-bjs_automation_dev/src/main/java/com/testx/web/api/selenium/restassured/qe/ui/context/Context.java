package com.testx.web.api.selenium.restassured.qe.ui.context;

public enum Context {
    PRODUCT_NAME1, PRODUCT_NAME2, Price_PizzaMini, Price_BistroBurger,

    Price, Product,

    Time_ASAP
}
